document.addEventListener('DOMContentLoaded', () => {
    const taskBoard = document.getElementById('taskBoard');
    const taskForm = document.getElementById('taskForm');
    const taskModal = document.getElementById('taskModal');
    const openModalBtn = document.getElementById('openModalBtn');
    const closeModalBtn = document.getElementById('closeModalBtn');
    const modalTitle = document.getElementById('modalTitle');

    let currentEditingId = null;

    // Fetch and display tasks
    const fetchTasks = async () => {
        try {
            const response = await fetch('/api/tasks');
            const tasks = await response.json();
            renderTasks(tasks);
        } catch (error) {
            console.error('Error fetching tasks:', error);
        }
    };

    const renderTasks = (tasks) => {
        taskBoard.innerHTML = '';
        tasks.sort((a,b) => new Date(a.deadline) - new Date(b.deadline)).forEach(task => {
            const statusClass = `status-${task.status.toLowerCase().replace(' ', '-')}`;
            const initials = task.assigned_user.split(' ').map(n => n[0]).join('').toUpperCase();
            
            const card = document.createElement('div');
            card.className = 'task-card';
            card.innerHTML = `
                <div class="task-status ${statusClass}">${task.status}</div>
                <h3 class="task-title">${task.title}</h3>
                <p class="task-desc">${task.description}</p>
                <div class="task-meta">
                    <div class="assigned-user">
                        <div class="avatar">${initials}</div>
                        <span>${task.assigned_user}</span>
                    </div>
                    <span><i class="ph ph-calendar"></i> ${new Date(task.deadline).toLocaleDateString()}</span>
                </div>
                <div class="task-actions">
                    <button class="btn-icon" onclick="editTask('${task._id}')" title="Edit">
                        <i class="ph ph-note-pencil"></i>
                    </button>
                    <button class="btn-icon btn-delete" onclick="deleteTask('${task._id}')" title="Delete">
                        <i class="ph ph-trash"></i>
                    </button>
                    <button class="btn-icon" onclick="toggleStatus('${task._id}', '${task.status}')" title="Quick Status Change">
                        <i class="ph ph-arrows-clockwise"></i>
                    </button>
                </div>
            `;
            taskBoard.appendChild(card);
        });
    };

    // Modal logic
    openModalBtn.onclick = () => {
        currentEditingId = null;
        modalTitle.innerText = 'Create New Task';
        taskForm.reset();
        taskModal.style.display = 'flex';
    };

    closeModalBtn.onclick = () => {
        taskModal.style.display = 'none';
    };

    window.onclick = (event) => {
        if (event.target == taskModal) taskModal.style.display = 'none';
    };

    // Form submission
    taskForm.onsubmit = async (e) => {
        e.preventDefault();
        const formData = {
            title: document.getElementById('title').value,
            description: document.getElementById('description').value,
            assigned_user: document.getElementById('assigned_user').value,
            deadline: document.getElementById('deadline').value,
            status: document.getElementById('status').value
        };

        try {
            const url = currentEditingId ? `/api/tasks/${currentEditingId}` : '/api/tasks';
            const method = currentEditingId ? 'PUT' : 'POST';
            
            const response = await fetch(url, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                taskModal.style.display = 'none';
                fetchTasks();
            }
        } catch (error) {
            console.error('Error saving task:', error);
        }
    };

    // Global actions
    window.deleteTask = async (id) => {
        if (!confirm('Are you sure you want to delete this task?')) return;
        try {
            await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
            fetchTasks();
        } catch (error) {
            console.error('Error deleting task:', error);
        }
    };

    window.editTask = async (id) => {
        try {
            const response = await fetch('/api/tasks');
            const tasks = await response.json();
            const task = tasks.find(t => t._id === id);
            
            if (task) {
                currentEditingId = id;
                modalTitle.innerText = 'Edit Task';
                document.getElementById('title').value = task.title;
                document.getElementById('description').value = task.description;
                document.getElementById('assigned_user').value = task.assigned_user;
                document.getElementById('deadline').value = task.deadline;
                document.getElementById('status').value = task.status;
                taskModal.style.display = 'flex';
            }
        } catch (error) {
            console.error('Error loading task details:', error);
        }
    };

    window.toggleStatus = async (id, currentStatus) => {
        const statuses = ['Pending', 'In Progress', 'Completed'];
        const nextStatus = statuses[(statuses.indexOf(currentStatus) + 1) % statuses.length];
        
        try {
            await fetch(`/api/tasks/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: nextStatus })
            });
            fetchTasks();
        } catch (error) {
            console.error('Error updating status:', error);
        }
    };

    fetchTasks();
});
