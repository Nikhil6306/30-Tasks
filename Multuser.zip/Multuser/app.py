from flask import Flask, render_template, request, jsonify
from pymongo import MongoClient
from bson import ObjectId
import json
from datetime import datetime

app = Flask(__name__)

# MongoDB Configuration
client = MongoClient("mongodb://localhost:27017/")
db = client["task_collaboration_db"]
tasks_collection = db["tasks"]

def task_serializer(task):
    task["_id"] = str(task["_id"])
    return task

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/tasks", methods=["GET"])
def get_tasks():
    tasks = list(tasks_collection.find())
    return jsonify([task_serializer(t) for t in tasks])

@app.route("/api/tasks", methods=["POST"])
def add_task():
    data = request.json
    new_task = {
        "title": data.get("title"),
        "description": data.get("description"),
        "assigned_user": data.get("assigned_user"),
        "deadline": data.get("deadline"),
        "status": data.get("status", "Pending"),
        "created_at": datetime.utcnow().isoformat()
    }
    result = tasks_collection.insert_one(new_task)
    new_task["_id"] = str(result.inserted_id)
    return jsonify(new_task), 201

@app.route("/api/tasks/<task_id>", methods=["PUT"])
def update_task(task_id):
    data = request.json
    update_data = {}
    
    if "title" in data: update_data["title"] = data["title"]
    if "description" in data: update_data["description"] = data["description"]
    if "assigned_user" in data: update_data["assigned_user"] = data["assigned_user"]
    if "deadline" in data: update_data["deadline"] = data["deadline"]
    if "status" in data: update_data["status"] = data["status"]
    
    tasks_collection.update_one({"_id": ObjectId(task_id)}, {"$set": update_data})
    return jsonify({"message": "Task updated successfully"}), 200

@app.route("/api/tasks/<task_id>", methods=["DELETE"])
def delete_task(task_id):
    tasks_collection.delete_one({"_id": ObjectId(task_id)})
    return jsonify({"message": "Task deleted successfully"}), 200

if __name__ == "__main__":
    app.run(debug=True, port=5000)
