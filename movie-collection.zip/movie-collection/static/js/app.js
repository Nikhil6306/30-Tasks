document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const gallery = document.getElementById('movieGallery');
    const modal = document.getElementById('movieModal');
    const form = document.getElementById('movieForm');
    const addBtn = document.getElementById('addMovieBtn');
    const closeBtn = document.getElementById('closeModalBtn');
    const cancelBtn = document.getElementById('cancelBtn');
    const modalTitle = document.getElementById('modalTitle');
    const toast = document.getElementById('toast');
    const toastIcon = document.getElementById('toastIcon');
    const toastMsg = document.getElementById('toastMsg');

    let isEditing = false;
    let toastTimeout;

    // Default Images based on Genre
    const defaultCovers = {
        'Action': 'https://images.unsplash.com/photo-1534809027769-621f2bb0a049?auto=format&fit=crop&q=80&w=800',
        'Comedy': 'https://images.unsplash.com/photo-1543807535-ece33d4e1fa4?auto=format&fit=crop&q=80&w=800',
        'Drama': 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&q=80&w=800',
        'Sci-Fi': 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&q=80&w=800',
        'Horror': 'https://images.unsplash.com/photo-1505635552518-3448ff116af3?auto=format&fit=crop&q=80&w=800',
        'Romance': 'https://images.unsplash.com/photo-1494774157365-9e04c6720e47?auto=format&fit=crop&q=80&w=800',
        'Thriller': 'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?auto=format&fit=crop&q=80&w=800',
        'Documentary': 'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?auto=format&fit=crop&q=80&w=800',
        'default': 'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&q=80&w=800'
    };

    // Load Initial Data
    fetchMovies();

    // Event Listeners
    addBtn.addEventListener('click', openAddModal);
    closeBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);
    form.addEventListener('submit', handleFormSubmit);

    // API Calls
    async function fetchMovies() {
        try {
            const res = await fetch('/api/movies');
            const data = await res.json();
            renderMovies(data);
        } catch (error) {
            showToast('Error fetching movies', 'error');
            gallery.innerHTML = '<div class="empty-state"><i class="fa-solid fa-triangle-exclamation"></i><h3>Backend Error</h3><p>Failed to load movies. Is the backend running?</p></div>';
        }
    }

    async function handleFormSubmit(e) {
        e.preventDefault();
        
        const movieId = document.getElementById('movieId').value;
        const movieData = {
            title: document.getElementById('title').value,
            director: document.getElementById('director').value,
            year: document.getElementById('year').value,
            genre: document.getElementById('genre').value,
            coverUrl: document.getElementById('coverUrl').value
        };

        const url = isEditing ? `/api/movies/${movieId}` : '/api/movies';
        const method = isEditing ? 'PUT' : 'POST';

        try {
            const res = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(movieData)
            });

            if (res.ok) {
                showToast(`Movie ${isEditing ? 'updated' : 'added'} successfully`, 'success');
                closeModal();
                fetchMovies();
            } else {
                const err = await res.json();
                showToast(err.error || 'Operation failed', 'error');
            }
        } catch (error) {
            showToast('Network error', 'error');
        }
    }

    window.deleteMovie = async (id) => {
        if (!confirm('Are you sure you want to delete this movie?')) return;
        
        try {
            const res = await fetch(`/api/movies/${id}`, { method: 'DELETE' });
            if (res.ok) {
                showToast('Movie deleted', 'success');
                fetchMovies();
            } else {
                showToast('Failed to delete movie', 'error');
            }
        } catch (error) {
            showToast('Network error', 'error');
        }
    };

    window.editMovie = (id, title, director, year, genre, coverUrl) => {
        isEditing = true;
        modalTitle.textContent = 'Edit Movie';
        
        document.getElementById('movieId').value = id;
        document.getElementById('title').value = title;
        document.getElementById('director').value = director;
        document.getElementById('year').value = year;
        document.getElementById('genre').value = genre;
        document.getElementById('coverUrl').value = coverUrl;
        
        modal.classList.add('active');
    };

    // UI Functions
    function renderMovies(movies) {
        if (!movies || movies.length === 0 || movies.error) {
            gallery.innerHTML = `
                <div class="empty-state">
                    <i class="fa-solid fa-film"></i>
                    <h3>No movies found</h3>
                    <p>Click "Add Movie" to start building your collection.</p>
                </div>`;
            return;
        }

        gallery.innerHTML = movies.map(movie => {
            const coverImage = movie.coverUrl || defaultCovers[movie.genre] || defaultCovers['default'];
            
            // Escape quotes for safe function calls
            const safeTitle = (movie.title || '').replace(/'/g, "\\'");
            const safeDirector = (movie.director || '').replace(/'/g, "\\'");
            
            return `
                <div class="movie-card glass-panel">
                    <img src="${coverImage}" alt="${movie.title}" class="movie-poster" onerror="this.src='${defaultCovers['default']}'">
                    <div class="movie-info">
                        <div class="movie-header">
                            <h3 class="movie-title">${movie.title}</h3>
                            ${movie.year ? `<span class="movie-year">${movie.year}</span>` : ''}
                        </div>
                        <p class="movie-director">Dir: ${movie.director}</p>
                        ${movie.genre ? `<div class="movie-genre">${movie.genre}</div>` : ''}
                        
                        <div class="movie-actions">
                            <button class="btn-icon-edit" onclick="editMovie('${movie._id}', '${safeTitle}', '${safeDirector}', '${movie.year || ''}', '${movie.genre || ''}', '${movie.coverUrl || ''}')">
                                <i class="fa-regular fa-pen-to-square"></i>
                            </button>
                            <button class="btn-icon-danger" onclick="deleteMovie('${movie._id}')">
                                <i class="fa-regular fa-trash-can"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    function openAddModal() {
        isEditing = false;
        modalTitle.textContent = 'Add New Movie';
        form.reset();
        document.getElementById('movieId').value = '';
        modal.classList.add('active');
    }

    function closeModal() {
        modal.classList.remove('active');
    }

    function showToast(message, type) {
        clearTimeout(toastTimeout);
        
        toastMsg.textContent = message;
        toastIcon.className = type === 'success' ? 'fa-solid fa-circle-check success' : 'fa-solid fa-circle-exclamation error';
        
        toast.classList.add('show');
        
        toastTimeout = setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }
});
