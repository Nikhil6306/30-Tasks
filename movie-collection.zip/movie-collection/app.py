import os
from flask import Flask, request, jsonify, render_template
from pymongo import MongoClient
from bson.objectid import ObjectId
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

# Configure MongoDB
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
client = MongoClient(MONGO_URI)
db = client.movie_collection
movies_collection = db.movies

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/movies', methods=['GET'])
def get_movies():
    try:
        movies = list(movies_collection.find())
        # Convert ObjectId to string for JSON serialization
        for movie in movies:
            movie['_id'] = str(movie['_id'])
        return jsonify(movies), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/movies', methods=['POST'])
def add_movie():
    try:
        data = request.json
        if not data.get('title') or not data.get('director'):
            return jsonify({"error": "Title and Director are required"}), 400
            
        new_movie = {
            "title": data.get("title"),
            "director": data.get("director"),
            "year": data.get("year", ""),
            "genre": data.get("genre", ""),
            "coverUrl": data.get("coverUrl", "")
        }
        
        result = movies_collection.insert_one(new_movie)
        new_movie['_id'] = str(result.inserted_id)
        
        return jsonify(new_movie), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/movies/<id>', methods=['PUT'])
def update_movie(id):
    try:
        data = request.json
        update_data = {}
        
        for field in ["title", "director", "year", "genre", "coverUrl"]:
            if field in data:
                update_data[field] = data[field]
                
        if not update_data:
            return jsonify({"error": "No data to update"}), 400
            
        result = movies_collection.update_one(
            {"_id": ObjectId(id)},
            {"$set": update_data}
        )
        
        if result.matched_count == 0:
            return jsonify({"error": "Movie not found"}), 404
            
        return jsonify({"message": "Movie updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/movies/<id>', methods=['DELETE'])
def delete_movie(id):
    try:
        result = movies_collection.delete_one({"_id": ObjectId(id)})
        
        if result.deleted_count == 0:
            return jsonify({"error": "Movie not found"}), 404
            
        return jsonify({"message": "Movie deleted successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
