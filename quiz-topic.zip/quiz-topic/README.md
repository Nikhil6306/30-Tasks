# 📚 Quiz Question Manager

A full-stack CRUD application to manage quiz questions, built with **Flask**, **MongoDB**, and vanilla **HTML/CSS/JS**.

---

## 🗂️ Project Structure

```
quiz-manager/
├── app.py                  # Flask backend (all API routes)
├── requirements.txt        # Python dependencies
├── templates/
│   └── index.html          # Single-page frontend shell
└── static/
    ├── css/style.css       # Styles
    └── js/main.js          # Frontend logic (CRUD)
```

---

## ⚙️ Setup & Run

### 1. Install MongoDB
Make sure MongoDB is running locally on port `27017`.  
Or set the `MONGO_URI` environment variable to point to your instance.

### 2. Install Python dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the app
```bash
python app.py
```

Open your browser at **http://localhost:5000**

---

## 🔌 REST API Reference

| Method | Endpoint                  | Description         |
|--------|---------------------------|---------------------|
| GET    | `/api/questions`          | Get all questions   |
| GET    | `/api/questions/<id>`     | Get one question    |
| POST   | `/api/questions`          | Create a question   |
| PUT    | `/api/questions/<id>`     | Update a question   |
| DELETE | `/api/questions/<id>`     | Delete a question   |

### Question Schema
```json
{
  "_id": "ObjectId (auto-generated)",
  "question": "What is the capital of France?",
  "options": ["Paris", "Berlin", "Rome", "Madrid"],
  "correct_answer": "Paris",
  "category": "Geography"
}
```

### POST /api/questions — Example Body
```json
{
  "question": "What is 2 + 2?",
  "options": ["3", "4", "5", "6"],
  "correct_answer": "4",
  "category": "Math"
}
```

---

## ✨ Features
- **Create** — Add questions with 4 options and mark the correct one
- **Read** — View all questions in a card grid; click any card for full detail
- **Update** — Edit any field inline via the edit form
- **Delete** — Confirmation modal before permanent deletion
- **Filter** — Real-time search by category or question text
- **Sort** — Sort alphabetically or by category
