from flask import Flask, request, jsonify, render_template
from pymongo import MongoClient
from bson import ObjectId
from bson.errors import InvalidId
import os

app = Flask(__name__)

# ── MongoDB Connection ──────────────────────────────────────────────────────
MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/")
client = MongoClient(MONGO_URI)
db = client["quiz_manager"]
questions_col = db["questions"]


# ── Helper ──────────────────────────────────────────────────────────────────
def serialize(doc):
    doc["_id"] = str(doc["_id"])
    return doc


# ── Frontend ─────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")


# ── CREATE ───────────────────────────────────────────────────────────────────
@app.route("/api/questions", methods=["POST"])
def create_question():
    data = request.get_json()

    required = ["question", "options", "correct_answer", "category"]
    for field in required:
        if field not in data or not data[field]:
            return jsonify({"error": f"'{field}' is required"}), 400

    if not isinstance(data["options"], list) or len(data["options"]) != 4:
        return jsonify({"error": "Exactly 4 options are required"}), 400

    if data["correct_answer"] not in data["options"]:
        return jsonify({"error": "correct_answer must be one of the options"}), 400

    result = questions_col.insert_one({
        "question":       data["question"].strip(),
        "options":        [o.strip() for o in data["options"]],
        "correct_answer": data["correct_answer"].strip(),
        "category":       data["category"].strip(),
    })

    new_doc = questions_col.find_one({"_id": result.inserted_id})
    return jsonify(serialize(new_doc)), 201


# ── READ ALL ──────────────────────────────────────────────────────────────────
@app.route("/api/questions", methods=["GET"])
def get_questions():
    category = request.args.get("category", "").strip()
    query = {"category": {"$regex": category, "$options": "i"}} if category else {}
    docs = [serialize(d) for d in questions_col.find(query)]
    return jsonify(docs), 200


# ── READ ONE ──────────────────────────────────────────────────────────────────
@app.route("/api/questions/<qid>", methods=["GET"])
def get_question(qid):
    try:
        doc = questions_col.find_one({"_id": ObjectId(qid)})
    except InvalidId:
        return jsonify({"error": "Invalid ID"}), 400

    if not doc:
        return jsonify({"error": "Question not found"}), 404

    return jsonify(serialize(doc)), 200


# ── UPDATE ────────────────────────────────────────────────────────────────────
@app.route("/api/questions/<qid>", methods=["PUT"])
def update_question(qid):
    try:
        oid = ObjectId(qid)
    except InvalidId:
        return jsonify({"error": "Invalid ID"}), 400

    data = request.get_json()
    update_fields = {}

    if "question" in data and data["question"]:
        update_fields["question"] = data["question"].strip()
    if "options" in data:
        if not isinstance(data["options"], list) or len(data["options"]) != 4:
            return jsonify({"error": "Exactly 4 options are required"}), 400
        update_fields["options"] = [o.strip() for o in data["options"]]
    if "correct_answer" in data and data["correct_answer"]:
        update_fields["correct_answer"] = data["correct_answer"].strip()
    if "category" in data and data["category"]:
        update_fields["category"] = data["category"].strip()

    if not update_fields:
        return jsonify({"error": "No valid fields to update"}), 400

    result = questions_col.update_one({"_id": oid}, {"$set": update_fields})
    if result.matched_count == 0:
        return jsonify({"error": "Question not found"}), 404

    updated = questions_col.find_one({"_id": oid})
    return jsonify(serialize(updated)), 200


# ── DELETE ────────────────────────────────────────────────────────────────────
@app.route("/api/questions/<qid>", methods=["DELETE"])
def delete_question(qid):
    try:
        oid = ObjectId(qid)
    except InvalidId:
        return jsonify({"error": "Invalid ID"}), 400

    result = questions_col.delete_one({"_id": oid})
    if result.deleted_count == 0:
        return jsonify({"error": "Question not found"}), 404

    return jsonify({"message": "Question deleted successfully"}), 200


if __name__ == "__main__":
    app.run(debug=True, port=5000)
