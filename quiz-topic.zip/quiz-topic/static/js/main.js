/* ── STATE ──────────────────────────────────────────────────────── */
let allQuestions = [];
let deleteTargetId = null;

/* ── INIT ───────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  loadQuestions();
});

/* ── NAVIGATION ──────────────────────────────────────────────────── */
function showView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(`view-${name}`).classList.add('active');
  document.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
  if (name === 'list') {
    document.querySelectorAll('.pill')[0].classList.add('active');
    loadQuestions();
  } else if (name === 'add') {
    document.querySelectorAll('.pill')[1].classList.add('active');
    clearAddForm();
  }
}

/* ── TOAST ───────────────────────────────────────────────────────── */
function showToast(msg, type = 'success') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `toast ${type} show`;
  setTimeout(() => { t.classList.remove('show'); }, 3000);
}

/* ── API HELPERS ─────────────────────────────────────────────────── */
async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

/* ── LOAD QUESTIONS ──────────────────────────────────────────────── */
async function loadQuestions() {
  try {
    allQuestions = await api('/api/questions');
    renderGrid(allQuestions);
    updateBadge(allQuestions.length);
  } catch (e) {
    showToast(e.message, 'error');
  }
}

function updateBadge(n) {
  document.getElementById('total-badge').textContent = `${n} Question${n !== 1 ? 's' : ''}`;
}

/* ── RENDER GRID ─────────────────────────────────────────────────── */
function renderGrid(questions) {
  const grid = document.getElementById('question-grid');
  const empty = document.getElementById('empty-state');

  if (!questions.length) {
    grid.innerHTML = '';
    empty.classList.remove('hidden');
    return;
  }
  empty.classList.add('hidden');

  const OPTS = ['A', 'B', 'C', 'D'];

  grid.innerHTML = questions.map((q, idx) => {
    const optionsHtml = q.options.map((opt, i) => {
      const letter = OPTS[i];
      const isCorrIdx = q.options.indexOf(q.correct_answer) === i;
      return `
        <div class="card-option ${isCorrIdx ? 'correct' : ''}">
          <span class="opt-key">${letter}</span>
          <span>${escHtml(opt)}</span>
        </div>`;
    }).join('');

    return `
      <div class="q-card" onclick="viewDetail('${q._id}')" style="animation-delay:${idx * 40}ms">
        <div class="card-top">
          <span class="category-chip">${escHtml(q.category)}</span>
          <div class="card-actions">
            <button class="icon-btn edit" title="Edit"
              onclick="event.stopPropagation(); openEdit('${q._id}')">✏️</button>
            <button class="icon-btn del" title="Delete"
              onclick="event.stopPropagation(); confirmDelete('${q._id}')">🗑️</button>
          </div>
        </div>
        <p class="card-question">${escHtml(q.question)}</p>
        <div class="card-options">${optionsHtml}</div>
      </div>`;
  }).join('');
}

/* ── FILTER & SORT ───────────────────────────────────────────────── */
function filterQuestions() {
  const q = document.getElementById('search-category').value.toLowerCase();
  const filtered = allQuestions.filter(item =>
    item.category.toLowerCase().includes(q) ||
    item.question.toLowerCase().includes(q)
  );
  renderGrid(filtered);
  updateBadge(filtered.length);
}

function sortQuestions() {
  const val = document.getElementById('sort-select').value;
  let sorted = [...allQuestions];
  if (val === 'category') sorted.sort((a,b) => a.category.localeCompare(b.category));
  if (val === 'alpha')    sorted.sort((a,b) => a.question.localeCompare(b.question));
  renderGrid(sorted);
}

/* ── VIEW DETAIL ─────────────────────────────────────────────────── */
async function viewDetail(id) {
  try {
    const q = await api(`/api/questions/${id}`);
    const OPTS = ['A','B','C','D'];
    const optHtml = q.options.map((opt, i) => {
      const isCorr = opt === q.correct_answer;
      return `
        <div class="detail-option ${isCorr ? 'correct' : ''}">
          <span class="detail-opt-key">${OPTS[i]}</span>
          <span class="detail-opt-text">${escHtml(opt)}</span>
          ${isCorr ? '<span class="correct-badge">✓ Correct</span>' : ''}
        </div>`;
    }).join('');

    document.getElementById('detail-content').innerHTML = `
      <div class="detail-card">
        <div class="detail-meta">
          <span class="category-chip">${escHtml(q.category)}</span>
        </div>
        <h2 class="detail-question">${escHtml(q.question)}</h2>
        <div class="detail-options">${optHtml}</div>
        <div style="margin-top:32px;display:flex;gap:12px;">
          <button class="btn-primary" onclick="openEdit('${q._id}')">Edit Question</button>
          <button class="btn-ghost" onclick="confirmDelete('${q._id}')">Delete</button>
        </div>
      </div>`;

    showView('detail');
  } catch(e) {
    showToast(e.message, 'error');
  }
}

/* ── ADD FORM ────────────────────────────────────────────────────── */
function clearAddForm() {
  ['f-question','f-category','f-opt-a','f-opt-b','f-opt-c','f-opt-d']
    .forEach(id => document.getElementById(id).value = '');
  document.getElementById('f-correct').value = '';
}

async function submitAdd() {
  const question = document.getElementById('f-question').value.trim();
  const category = document.getElementById('f-category').value.trim();
  const opts     = ['f-opt-a','f-opt-b','f-opt-c','f-opt-d'].map(id =>
    document.getElementById(id).value.trim()
  );
  const corrLetter = document.getElementById('f-correct').value;

  if (!question || !category || opts.some(o => !o) || !corrLetter) {
    return showToast('Please fill in all fields.', 'error');
  }

  const OPTS = ['A','B','C','D'];
  const correct_answer = opts[OPTS.indexOf(corrLetter)];

  try {
    await api('/api/questions', {
      method: 'POST',
      body: JSON.stringify({ question, options: opts, correct_answer, category }),
    });
    showToast('Question added! 🎉');
    showView('list');
  } catch(e) {
    showToast(e.message, 'error');
  }
}

/* ── EDIT FORM ───────────────────────────────────────────────────── */
async function openEdit(id) {
  try {
    const q = await api(`/api/questions/${id}`);
    document.getElementById('e-id').value = q._id;
    document.getElementById('e-question').value = q.question;
    document.getElementById('e-category').value = q.category;
    const ids = ['e-opt-a','e-opt-b','e-opt-c','e-opt-d'];
    q.options.forEach((opt, i) => document.getElementById(ids[i]).value = opt);
    const OPTS = ['A','B','C','D'];
    const corrIdx = q.options.indexOf(q.correct_answer);
    document.getElementById('e-correct').value = OPTS[corrIdx] || 'A';
    showView('edit');
  } catch(e) {
    showToast(e.message, 'error');
  }
}

async function submitEdit() {
  const id       = document.getElementById('e-id').value;
  const question = document.getElementById('e-question').value.trim();
  const category = document.getElementById('e-category').value.trim();
  const opts     = ['e-opt-a','e-opt-b','e-opt-c','e-opt-d'].map(id =>
    document.getElementById(id).value.trim()
  );
  const corrLetter = document.getElementById('e-correct').value;

  if (!question || !category || opts.some(o => !o) || !corrLetter) {
    return showToast('Please fill in all fields.', 'error');
  }

  const OPTS = ['A','B','C','D'];
  const correct_answer = opts[OPTS.indexOf(corrLetter)];

  try {
    await api(`/api/questions/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ question, options: opts, correct_answer, category }),
    });
    showToast('Question updated! ✅');
    showView('list');
  } catch(e) {
    showToast(e.message, 'error');
  }
}

/* ── DELETE ──────────────────────────────────────────────────────── */
function confirmDelete(id) {
  deleteTargetId = id;
  document.getElementById('modal-overlay').classList.remove('hidden');
  document.getElementById('confirm-delete-btn').onclick = executeDelete;
}

function closeModal() {
  document.getElementById('modal-overlay').classList.add('hidden');
  deleteTargetId = null;
}

async function executeDelete() {
  if (!deleteTargetId) return;
  try {
    await api(`/api/questions/${deleteTargetId}`, { method: 'DELETE' });
    showToast('Question deleted.');
    closeModal();
    showView('list');
  } catch(e) {
    showToast(e.message, 'error');
    closeModal();
  }
}

/* ── UTILS ───────────────────────────────────────────────────────── */
function escHtml(str) {
  return String(str)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}

/* Close modal on overlay click */
document.getElementById('modal-overlay').addEventListener('click', function(e) {
  if (e.target === this) closeModal();
});
