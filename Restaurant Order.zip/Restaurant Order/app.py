from flask import Flask, render_template, request, jsonify, redirect, url_for
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime
import json

app = Flask(__name__)

# MongoDB Connection
client = MongoClient("mongodb://localhost:27017/")
db = client["restaurant_db"]
menu_collection = db["menu_items"]
orders_collection = db["orders"]

# ─── HELPER ────────────────────────────────────────────────
def serialize(doc):
    doc["_id"] = str(doc["_id"])
    return doc

# ─── ROUTES ────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

# ── Menu CRUD ──────────────────────────────────────────────

@app.route("/menu")
def menu():
    items = [serialize(i) for i in menu_collection.find()]
    return render_template("menu.html", items=items)

@app.route("/api/menu", methods=["GET"])
def get_menu():
    items = [serialize(i) for i in menu_collection.find()]
    return jsonify(items)

@app.route("/api/menu", methods=["POST"])
def add_menu_item():
    data = request.json
    item = {
        "name": data["name"],
        "category": data["category"],
        "price": float(data["price"]),
        "description": data.get("description", "")
    }
    result = menu_collection.insert_one(item)
    item["_id"] = str(result.inserted_id)
    return jsonify(item), 201

@app.route("/api/menu/<item_id>", methods=["PUT"])
def update_menu_item(item_id):
    data = request.json
    menu_collection.update_one(
        {"_id": ObjectId(item_id)},
        {"$set": {
            "name": data["name"],
            "category": data["category"],
            "price": float(data["price"]),
            "description": data.get("description", "")
        }}
    )
    return jsonify({"message": "Updated"})

@app.route("/api/menu/<item_id>", methods=["DELETE"])
def delete_menu_item(item_id):
    menu_collection.delete_one({"_id": ObjectId(item_id)})
    return jsonify({"message": "Deleted"})

# ── Orders CRUD ────────────────────────────────────────────

@app.route("/orders")
def orders():
    all_orders = [serialize(o) for o in orders_collection.find().sort("created_at", -1)]
    menu_items = [serialize(i) for i in menu_collection.find()]
    return render_template("orders.html", orders=all_orders, menu_items=menu_items)

@app.route("/api/orders", methods=["GET"])
def get_orders():
    all_orders = [serialize(o) for o in orders_collection.find().sort("created_at", -1)]
    return jsonify(all_orders)

@app.route("/api/orders", methods=["POST"])
def create_order():
    data = request.json
    items = data["items"]  # list of {item_id, name, price, quantity}
    total = sum(i["price"] * i["quantity"] for i in items)
    order = {
        "customer_name": data["customer_name"],
        "table_number": int(data["table_number"]),
        "items": items,
        "total_bill": round(total, 2),
        "status": "Pending",
        "created_at": datetime.utcnow().isoformat()
    }
    result = orders_collection.insert_one(order)
    order["_id"] = str(result.inserted_id)
    return jsonify(order), 201

@app.route("/api/orders/<order_id>", methods=["PUT"])
def update_order(order_id):
    data = request.json
    update_fields = {}
    if "status" in data:
        update_fields["status"] = data["status"]
    if "items" in data:
        total = sum(i["price"] * i["quantity"] for i in data["items"])
        update_fields["items"] = data["items"]
        update_fields["total_bill"] = round(total, 2)
    if "customer_name" in data:
        update_fields["customer_name"] = data["customer_name"]
    if "table_number" in data:
        update_fields["table_number"] = int(data["table_number"])
    orders_collection.update_one({"_id": ObjectId(order_id)}, {"$set": update_fields})
    return jsonify({"message": "Order updated"})

@app.route("/api/orders/<order_id>", methods=["DELETE"])
def delete_order(order_id):
    orders_collection.delete_one({"_id": ObjectId(order_id)})
    return jsonify({"message": "Order deleted"})

if __name__ == "__main__":
    app.run(debug=True)