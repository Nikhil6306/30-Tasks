from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime
import json

app = Flask(__name__)
CORS(app)

# MongoDB connection
try:
    client = MongoClient('mongodb://localhost:27017/', serverSelectionTimeoutMS=3000)
    client.server_info()
    db = client['college_erp']
    USE_DB = True
    print("Connected to MongoDB")
except:
    USE_DB = False
    print("MongoDB not available — using in-memory store")

# ── In-memory fallback ──────────────────────────────────────────────
store = {
    'students':   [],
    'teachers':   [],
    'courses':    [],
    'attendance': [],
    'fees':       [],
    'results':    [],
    'notices':    [],
    'library':    [],
}

def _id():
    import uuid
    return str(uuid.uuid4())[:8]

def seed_data():
    """Seed some demo data into in-memory store."""
    if not store['students']:
        store['students'] = [
            {'_id':'s1','name':'Alice Johnson','roll':'CS001','email':'alice@college.edu','phone':'9876543210','course':'B.Tech CS','year':'2','dob':'2003-05-12','gender':'Female','address':'123 Main St','created_at':datetime.now().isoformat()},
            {'_id':'s2','name':'Bob Smith','roll':'CS002','email':'bob@college.edu','phone':'9876543211','course':'B.Tech CS','year':'2','dob':'2003-08-22','gender':'Male','address':'456 Oak Ave','created_at':datetime.now().isoformat()},
            {'_id':'s3','name':'Clara Davis','roll':'EC001','email':'clara@college.edu','phone':'9876543212','course':'B.Tech EC','year':'3','dob':'2002-11-05','gender':'Female','address':'789 Pine Rd','created_at':datetime.now().isoformat()},
        ]
    if not store['teachers']:
        store['teachers'] = [
            {'_id':'t1','name':'Dr. Robert Wilson','employee_id':'EMP001','email':'rwilson@college.edu','phone':'9876500001','department':'Computer Science','designation':'Professor','qualification':'PhD CS','experience':'12','subject':'Data Structures','salary':'85000','created_at':datetime.now().isoformat()},
            {'_id':'t2','name':'Prof. Sarah Lee','employee_id':'EMP002','email':'slee@college.edu','phone':'9876500002','department':'Electronics','designation':'Associate Professor','qualification':'M.Tech','experience':'8','subject':'Circuits','salary':'72000','created_at':datetime.now().isoformat()},
        ]
    if not store['courses']:
        store['courses'] = [
            {'_id':'c1','code':'CS301','name':'Data Structures','department':'Computer Science','credits':'4','semester':'3','teacher':'Dr. Robert Wilson','description':'Arrays, Linked Lists, Trees, Graphs','duration':'6 months','created_at':datetime.now().isoformat()},
            {'_id':'c2','code':'CS302','name':'Database Management','department':'Computer Science','credits':'3','semester':'4','teacher':'Dr. Robert Wilson','description':'SQL, NoSQL, Transactions','duration':'6 months','created_at':datetime.now().isoformat()},
        ]
    if not store['notices']:
        store['notices'] = [
            {'_id':'n1','title':'Exam Schedule Released','content':'Mid-semester exams begin Nov 15. Check timetable on portal.','category':'Exam','date':'2024-11-01','priority':'High','posted_by':'Admin','created_at':datetime.now().isoformat()},
            {'_id':'n2','title':'Annual Sports Day','content':'Annual sports day on Dec 10. Register by Nov 30.','category':'Event','date':'2024-11-05','priority':'Medium','posted_by':'Admin','created_at':datetime.now().isoformat()},
        ]
    if not store['library']:
        store['library'] = [
            {'_id':'l1','title':'Introduction to Algorithms','author':'CLRS','isbn':'978-0262033848','category':'Computer Science','copies':'5','available':'3','publisher':'MIT Press','edition':'3rd','year':'2009','created_at':datetime.now().isoformat()},
            {'_id':'l2','title':'Digital Electronics','author':'Morris Mano','isbn':'978-0132103243','category':'Electronics','copies':'8','available':'6','publisher':'Pearson','edition':'4th','year':'2012','created_at':datetime.now().isoformat()},
        ]

seed_data()

# ── Helper ──────────────────────────────────────────────────────────
def serialize(doc):
    if doc is None:
        return None
    if isinstance(doc, list):
        return [serialize(d) for d in doc]
    d = dict(doc)
    if '_id' in d and isinstance(d['_id'], ObjectId):
        d['_id'] = str(d['_id'])
    return d

def col(name):
    if USE_DB:
        return db[name]
    return None

# ── Generic CRUD helpers ────────────────────────────────────────────
def get_all(collection):
    if USE_DB:
        return serialize(list(col(collection).find()))
    return store[collection]

def get_one(collection, id_):
    if USE_DB:
        try:
            return serialize(col(collection).find_one({'_id': ObjectId(id_)}))
        except:
            return None
    return next((x for x in store[collection] if x['_id'] == id_), None)

def create_one(collection, data):
    data['created_at'] = datetime.now().isoformat()
    if USE_DB:
        result = col(collection).insert_one(data)
        data['_id'] = str(result.inserted_id)
        return data
    data['_id'] = _id()
    store[collection].append(data)
    return data

def update_one(collection, id_, data):
    data.pop('_id', None)
    if USE_DB:
        try:
            col(collection).update_one({'_id': ObjectId(id_)}, {'$set': data})
            return get_one(collection, id_)
        except:
            return None
    rec = next((x for x in store[collection] if x['_id'] == id_), None)
    if rec:
        rec.update(data)
    return rec

def delete_one(collection, id_):
    if USE_DB:
        try:
            col(collection).delete_one({'_id': ObjectId(id_)})
            return True
        except:
            return False
    before = len(store[collection])
    store[collection] = [x for x in store[collection] if x['_id'] != id_]
    return len(store[collection]) < before

# ── Routes: Main pages ──────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')

# ── Dashboard stats ──────────────────────────────────────────────────
@app.route('/api/dashboard')
def dashboard():
    stats = {}
    for name in ['students','teachers','courses','notices','library']:
        if USE_DB:
            stats[name] = col(name).count_documents({})
        else:
            stats[name] = len(store[name])
    # Fee collection
    if USE_DB:
        paid = col('fees').count_documents({'status':'Paid'})
        pending = col('fees').count_documents({'status':'Pending'})
    else:
        paid = sum(1 for f in store['fees'] if f.get('status')=='Paid')
        pending = sum(1 for f in store['fees'] if f.get('status')=='Pending')
    stats['fees_paid'] = paid
    stats['fees_pending'] = pending
    stats['recent_notices'] = get_all('notices')[-3:]
    return jsonify(stats)

# ── Generic CRUD factory ─────────────────────────────────────────────
def make_crud(collection):
    def get_list():
        return jsonify(get_all(collection))

    def create():
        data = request.get_json()
        return jsonify(create_one(collection, data)), 201

    def get_item(id):
        item = get_one(collection, id)
        if not item:
            return jsonify({'error': 'Not found'}), 404
        return jsonify(item)

    def update(id):
        data = request.get_json()
        item = update_one(collection, id, data)
        if not item:
            return jsonify({'error': 'Not found'}), 404
        return jsonify(item)

    def delete(id):
        if delete_one(collection, id):
            return jsonify({'message': 'Deleted'})
        return jsonify({'error': 'Not found'}), 404

    return get_list, create, get_item, update, delete

# Register CRUD routes
for module in ['students','teachers','courses','attendance','fees','results','notices','library']:
    gl, cr, gi, up, de = make_crud(module)
    app.add_url_rule(f'/api/{module}',        f'{module}_list',   gl, methods=['GET'])
    app.add_url_rule(f'/api/{module}',        f'{module}_create', cr, methods=['POST'])
    app.add_url_rule(f'/api/{module}/<id>',   f'{module}_get',    gi, methods=['GET'])
    app.add_url_rule(f'/api/{module}/<id>',   f'{module}_update', up, methods=['PUT'])
    app.add_url_rule(f'/api/{module}/<id>',   f'{module}_delete', de, methods=['DELETE'])

if __name__ == '__main__':
    app.run(debug=True, port=5000)
