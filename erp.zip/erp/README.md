# EduNexus — College ERP System

## Stack
- **Frontend**: HTML5, CSS3, Vanilla JavaScript (no frameworks)
- **Backend**: Python Flask REST API
- **Database**: MongoDB (falls back to in-memory if MongoDB unavailable)

## Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. (Optional) Start MongoDB
```bash
mongod --dbpath ./data
```
If MongoDB is not running, the app uses an in-memory store with demo data.

### 3. Run the server
```bash
python app.py
```
Visit **http://localhost:5000**

## Modules & CRUD
| Module     | Endpoint         | Fields |
|------------|-----------------|--------|
| Students   | /api/students   | name, roll, email, phone, course, year, dob, gender, address |
| Teachers   | /api/teachers   | name, employee_id, email, department, designation, salary … |
| Courses    | /api/courses    | code, name, department, credits, semester, teacher … |
| Attendance | /api/attendance | student_name, roll, course, date, status, teacher |
| Fees       | /api/fees       | student_name, fee_type, amount, due_date, status, payment_mode |
| Results    | /api/results    | student_name, subject, semester, marks, grade |
| Notices    | /api/notices    | title, content, category, date, priority |
| Library    | /api/library    | title, author, isbn, category, copies, available |

All modules support **GET** (list + single), **POST**, **PUT**, **DELETE**.
