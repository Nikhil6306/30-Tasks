/* ── EduNexus ERP — Frontend ─────────────────────────────── */
const API = '';
let currentModule = 'dashboard';
let editingId = null;
let allRecords = [];

// ── Init ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  updateDate();
  switchModule('dashboard');
});

function updateDate() {
  const el = document.getElementById('topbarDate');
  if (el) el.textContent = new Date().toLocaleDateString('en-US', { weekday:'short', month:'short', day:'numeric', year:'numeric' });
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

// ── Module switching ──────────────────────────────────────────
function switchModule(name) {
  currentModule = name;
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.querySelector(`[data-module="${name}"]`)?.classList.add('active');
  document.getElementById('pageTitle').textContent = capitalize(name);
  document.getElementById('sidebar').classList.remove('open');

  const c = document.getElementById('content');
  c.style.opacity = '0';
  c.style.transform = 'translateY(8px)';
  setTimeout(() => {
    c.style.transition = 'all .25s ease';
    c.style.opacity = '1';
    c.style.transform = 'translateY(0)';
  }, 50);

  if (name === 'dashboard') renderDashboard();
  else renderModule(name);
}

// ── Dashboard ─────────────────────────────────────────────────
async function renderDashboard() {
  const data = await apiFetch('/api/dashboard');
  const cards = [
    { label:'Students',  value: data.students,     icon:'◉', cls:'blue' },
    { label:'Teachers',  value: data.teachers,     icon:'◎', cls:'purple' },
    { label:'Courses',   value: data.courses,      icon:'▣', cls:'teal' },
    { label:'Library',   value: data.library,      icon:'▤', cls:'green' },
    { label:'Fees Paid', value: data.fees_paid,    icon:'◐', cls:'orange' },
    { label:'Pending',   value: data.fees_pending, icon:'◑', cls:'red' },
  ];

  const notices = (data.recent_notices || []).map(n => `
    <div class="notice-card">
      <div class="notice-priority-bar ${(n.priority||'low').toLowerCase()}"></div>
      <div class="notice-content">
        <h3>${esc(n.title)}</h3>
        <p>${esc(n.content||'')}</p>
        <div class="notice-meta">${esc(n.category||'')} · ${esc(n.date||'')}</div>
      </div>
    </div>`).join('') || '<p style="color:var(--text3);font-size:13px">No recent notices</p>';

  const quickLinks = [
    {label:'Add Student',  module:'students'},
    {label:'Add Teacher',  module:'teachers'},
    {label:'Add Course',   module:'courses'},
    {label:'Post Notice',  module:'notices'},
    {label:'Record Fee',   module:'fees'},
    {label:'Add Book',     module:'library'},
  ].map(q => `<button class="btn btn-ghost btn-sm" onclick="switchModule('${q.module}')">→ ${q.label}</button>`).join('');

  document.getElementById('content').innerHTML = `
    <div class="dashboard-grid">
      ${cards.map((c,i) => `
        <div class="stat-card" style="animation-delay:${i*50}ms">
          <div class="stat-icon ${c.cls}">${c.icon}</div>
          <div>
            <div class="stat-value">${c.value ?? 0}</div>
            <div class="stat-label">${c.label}</div>
          </div>
        </div>`).join('')}
    </div>
    <div class="dashboard-lower">
      <div class="dash-panel">
        <div class="dash-panel-title">Recent Notices</div>
        <div class="notice-list">${notices}</div>
      </div>
      <div class="dash-panel">
        <div class="dash-panel-title">Quick Actions</div>
        <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:4px">${quickLinks}</div>
      </div>
    </div>`;
}

// ── Module renderer ───────────────────────────────────────────
const SCHEMAS = {
  students: {
    title: 'Students',
    fields: [
      {k:'name',       l:'Full Name',     type:'text', req:true},
      {k:'roll',       l:'Roll Number',   type:'text', req:true},
      {k:'email',      l:'Email',         type:'email'},
      {k:'phone',      l:'Phone',         type:'text'},
      {k:'course',     l:'Course',        type:'text'},
      {k:'year',       l:'Year',          type:'select', opts:['1','2','3','4']},
      {k:'dob',        l:'Date of Birth', type:'date'},
      {k:'gender',     l:'Gender',        type:'select', opts:['Male','Female','Other']},
      {k:'address',    l:'Address',       type:'textarea', full:true},
    ],
    cols: ['name','roll','course','year','email','phone'],
    badge: r => badgeForYear(r.year),
  },
  teachers: {
    title: 'Teachers',
    fields: [
      {k:'name',         l:'Full Name',     type:'text', req:true},
      {k:'employee_id',  l:'Employee ID',   type:'text', req:true},
      {k:'email',        l:'Email',         type:'email'},
      {k:'phone',        l:'Phone',         type:'text'},
      {k:'department',   l:'Department',    type:'text'},
      {k:'designation',  l:'Designation',   type:'select', opts:['Professor','Associate Professor','Assistant Professor','Lecturer']},
      {k:'qualification',l:'Qualification', type:'text'},
      {k:'experience',   l:'Experience (yrs)', type:'number'},
      {k:'subject',      l:'Subject',       type:'text'},
      {k:'salary',       l:'Salary',        type:'number'},
    ],
    cols: ['name','employee_id','department','designation','subject','phone'],
    badge: r => `<span class="badge badge-purple">${esc(r.designation||'')}</span>`,
  },
  courses: {
    title: 'Courses',
    fields: [
      {k:'code',       l:'Course Code',   type:'text', req:true},
      {k:'name',       l:'Course Name',   type:'text', req:true},
      {k:'department', l:'Department',    type:'text'},
      {k:'credits',    l:'Credits',       type:'number'},
      {k:'semester',   l:'Semester',      type:'select', opts:['1','2','3','4','5','6','7','8']},
      {k:'teacher',    l:'Teacher',       type:'text'},
      {k:'duration',   l:'Duration',      type:'text'},
      {k:'description',l:'Description',   type:'textarea', full:true},
    ],
    cols: ['code','name','department','credits','semester','teacher'],
    badge: r => `<span class="badge badge-teal">Sem ${esc(r.semester||'')}</span>`,
  },
  attendance: {
    title: 'Attendance',
    fields: [
      {k:'student_name',l:'Student Name',  type:'text', req:true},
      {k:'roll',        l:'Roll No',       type:'text'},
      {k:'course',      l:'Course',        type:'text'},
      {k:'date',        l:'Date',          type:'date', req:true},
      {k:'status',      l:'Status',        type:'select', opts:['Present','Absent','Late'], req:true},
      {k:'teacher',     l:'Teacher',       type:'text'},
      {k:'remarks',     l:'Remarks',       type:'textarea', full:true},
    ],
    cols: ['student_name','roll','course','date','status','teacher'],
    badge: r => attendanceBadge(r.status),
  },
  fees: {
    title: 'Fees',
    fields: [
      {k:'student_name',l:'Student Name',  type:'text', req:true},
      {k:'roll',        l:'Roll No',       type:'text'},
      {k:'fee_type',    l:'Fee Type',      type:'select', opts:['Tuition','Hostel','Exam','Library','Lab','Misc']},
      {k:'amount',      l:'Amount (₹)',    type:'number', req:true},
      {k:'due_date',    l:'Due Date',      type:'date'},
      {k:'paid_date',   l:'Paid Date',     type:'date'},
      {k:'status',      l:'Status',        type:'select', opts:['Paid','Pending','Overdue']},
      {k:'payment_mode',l:'Payment Mode',  type:'select', opts:['Cash','Online','Cheque','DD']},
      {k:'remarks',     l:'Remarks',       type:'textarea', full:true},
    ],
    cols: ['student_name','roll','fee_type','amount','due_date','status'],
    badge: r => feeStatusBadge(r.status),
  },
  results: {
    title: 'Results',
    fields: [
      {k:'student_name',l:'Student Name',  type:'text', req:true},
      {k:'roll',        l:'Roll No',       type:'text'},
      {k:'course',      l:'Course',        type:'text'},
      {k:'semester',    l:'Semester',      type:'select', opts:['1','2','3','4','5','6','7','8']},
      {k:'subject',     l:'Subject',       type:'text'},
      {k:'marks',       l:'Marks Obtained',type:'number'},
      {k:'total_marks', l:'Total Marks',   type:'number'},
      {k:'grade',       l:'Grade',         type:'select', opts:['O','A+','A','B+','B','C','F']},
      {k:'remarks',     l:'Remarks',       type:'textarea', full:true},
    ],
    cols: ['student_name','roll','subject','semester','marks','grade'],
    badge: r => gradeBadge(r.grade),
  },
  notices: {
    title: 'Notices',
    fields: [
      {k:'title',    l:'Title',    type:'text', req:true, full:true},
      {k:'content',  l:'Content',  type:'textarea', full:true, req:true},
      {k:'category', l:'Category', type:'select', opts:['General','Exam','Event','Holiday','Academic','Administrative']},
      {k:'date',     l:'Date',     type:'date'},
      {k:'priority', l:'Priority', type:'select', opts:['High','Medium','Low']},
      {k:'posted_by',l:'Posted By',type:'text'},
    ],
    cols: ['title','category','date','priority','posted_by'],
    badge: r => priorityBadge(r.priority),
    customRender: renderNotices,
  },
  library: {
    title: 'Library',
    fields: [
      {k:'title',     l:'Book Title',   type:'text', req:true},
      {k:'author',    l:'Author',       type:'text', req:true},
      {k:'isbn',      l:'ISBN',         type:'text'},
      {k:'category',  l:'Category',     type:'text'},
      {k:'copies',    l:'Total Copies', type:'number'},
      {k:'available', l:'Available',    type:'number'},
      {k:'publisher', l:'Publisher',    type:'text'},
      {k:'edition',   l:'Edition',      type:'text'},
      {k:'year',      l:'Year',         type:'number'},
    ],
    cols: ['title','author','category','copies','available','isbn'],
    badge: r => availabilityBadge(r.available, r.copies),
  },
};

async function renderModule(name) {
  const schema = SCHEMAS[name];
  allRecords = await apiFetch(`/api/${name}`);

  const countLabel = `${allRecords.length} record${allRecords.length !== 1 ? 's' : ''}`;

  let html = `
    <div class="module-header">
      <div>
        <h1>${schema.title}</h1>
        <div class="module-meta">${countLabel}</div>
      </div>
      <button class="btn btn-primary" onclick="openCreateModal('${name}')">
        + Add ${schema.title.replace(/s$/,'')}
      </button>
    </div>
    <div class="search-bar">
      <input class="search-input" id="searchInput" placeholder="Search ${schema.title.toLowerCase()}…" oninput="filterTable('${name}')">
    </div>`;

  if (name === 'notices') {
    html += renderNotices(allRecords, name);
  } else {
    html += renderTable(allRecords, schema, name);
  }

  document.getElementById('content').innerHTML = html;
}

function renderTable(records, schema, name) {
  const cols = schema.cols;
  const thead = cols.map(c => `<th>${colLabel(c, schema)}</th>`).join('') + '<th>Actions</th>';

  const tbody = records.length === 0
    ? `<tr><td colspan="${cols.length+1}"><div class="empty-state"><div class="empty-icon">◌</div><p>No records yet. Click "Add" to get started.</p></div></td></tr>`
    : records.map(r => `
      <tr data-id="${r._id}">
        ${cols.map((c,i) => `<td>${i===0 ? `<strong>${esc(r[c]||'—')}</strong>` : esc(r[c]||'—')}</td>`).join('')}
        <td>
          <div class="action-row">
            ${schema.badge ? schema.badge(r) : ''}
            <button class="btn btn-ghost btn-sm" onclick="openEditModal('${name}','${r._id}')">Edit</button>
            <button class="btn btn-danger-ghost btn-sm" onclick="deleteRecord('${name}','${r._id}')">Delete</button>
          </div>
        </td>
      </tr>`).join('');

  return `<div class="table-wrap"><table><thead><tr>${thead}</tr></thead><tbody id="tableBody">${tbody}</tbody></table></div>`;
}

function renderNotices(records, name) {
  if (!records || records.length === 0)
    return `<div class="empty-state"><div class="empty-icon">◌</div><p>No notices yet.</p></div>`;
  return `<div class="notice-list" id="tableBody">` +
    records.map(n => `
      <div class="notice-card" data-id="${n._id}">
        <div class="notice-priority-bar ${(n.priority||'low').toLowerCase()}"></div>
        <div class="notice-content" style="flex:1">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <h3>${esc(n.title)}</h3>
            ${priorityBadge(n.priority)} ${noticeCatBadge(n.category)}
          </div>
          <p>${esc(n.content||'')}</p>
          <div class="notice-meta">Posted by ${esc(n.posted_by||'Admin')} · ${esc(n.date||'')}</div>
        </div>
        <div class="action-row" style="flex-shrink:0">
          <button class="btn btn-ghost btn-sm" onclick="openEditModal('notices','${n._id}')">Edit</button>
          <button class="btn btn-danger-ghost btn-sm" onclick="deleteRecord('notices','${n._id}')">Del</button>
        </div>
      </div>`).join('') + `</div>`;
}

// ── Filter ────────────────────────────────────────────────────
function filterTable(name) {
  const q = document.getElementById('searchInput').value.toLowerCase();
  const schema = SCHEMAS[name];
  const filtered = allRecords.filter(r =>
    schema.cols.some(c => String(r[c]||'').toLowerCase().includes(q))
  );
  const body = document.getElementById('tableBody');
  if (!body) return;
  if (name === 'notices') {
    body.outerHTML = renderNotices(filtered, name);
  } else {
    body.innerHTML = filtered.length === 0
      ? `<tr><td colspan="99"><div class="empty-state"><div class="empty-icon">◌</div><p>No results found.</p></div></td></tr>`
      : filtered.map(r => {
          const schema = SCHEMAS[name];
          return `<tr data-id="${r._id}">
            ${schema.cols.map((c,i) => `<td>${i===0 ? `<strong>${esc(r[c]||'—')}</strong>` : esc(r[c]||'—')}</td>`).join('')}
            <td><div class="action-row">
              ${schema.badge ? schema.badge(r) : ''}
              <button class="btn btn-ghost btn-sm" onclick="openEditModal('${name}','${r._id}')">Edit</button>
              <button class="btn btn-danger-ghost btn-sm" onclick="deleteRecord('${name}','${r._id}')">Delete</button>
            </div></td>
          </tr>`;
        }).join('');
  }
}

// ── Modal ─────────────────────────────────────────────────────
function openCreateModal(name) {
  editingId = null;
  const schema = SCHEMAS[name];
  document.getElementById('modalTitle').textContent = `Add ${schema.title.replace(/s$/,'')}`;
  document.getElementById('modalBody').innerHTML = buildForm(schema.fields, {});
  document.getElementById('modalSaveBtn').onclick = () => saveRecord(name);
  document.getElementById('modalSaveBtn').textContent = 'Add';
  openModal();
}

async function openEditModal(name, id) {
  editingId = id;
  const schema = SCHEMAS[name];
  const rec = await apiFetch(`/api/${name}/${id}`);
  document.getElementById('modalTitle').textContent = `Edit ${schema.title.replace(/s$/,'')}`;
  document.getElementById('modalBody').innerHTML = buildForm(schema.fields, rec);
  document.getElementById('modalSaveBtn').onclick = () => saveRecord(name);
  document.getElementById('modalSaveBtn').textContent = 'Update';
  openModal();
}

function buildForm(fields, values) {
  return `<div class="form-grid">${fields.map(f => {
    const cls = f.full ? 'form-group full' : 'form-group';
    const val = values[f.k] || '';
    if (f.type === 'textarea') {
      return `<div class="${cls}">
        <label class="form-label">${f.l}${f.req?' *':''}</label>
        <textarea class="form-textarea" name="${f.k}" rows="3">${esc(val)}</textarea>
      </div>`;
    }
    if (f.type === 'select') {
      const opts = (f.opts||[]).map(o => `<option value="${o}"${val===o?' selected':''}>${o}</option>`).join('');
      return `<div class="${cls}">
        <label class="form-label">${f.l}${f.req?' *':''}</label>
        <select class="form-select" name="${f.k}"><option value="">— Select —</option>${opts}</select>
      </div>`;
    }
    return `<div class="${cls}">
      <label class="form-label">${f.l}${f.req?' *':''}</label>
      <input class="form-input" type="${f.type||'text'}" name="${f.k}" value="${esc(val)}" ${f.req?'required':''}>
    </div>`;
  }).join('')}</div>`;
}

async function saveRecord(name) {
  const inputs = document.querySelectorAll('#modalBody [name]');
  const data = {};
  inputs.forEach(el => { data[el.name] = el.value; });

  try {
    if (editingId) {
      await apiFetch(`/api/${name}/${editingId}`, 'PUT', data);
      showToast('Record updated', 'success');
    } else {
      await apiFetch(`/api/${name}`, 'POST', data);
      showToast('Record created', 'success');
    }
    closeModal();
    renderModule(name);
  } catch (e) {
    showToast('Error saving record', 'error');
  }
}

async function deleteRecord(name, id) {
  if (!confirm('Delete this record permanently?')) return;
  try {
    await apiFetch(`/api/${name}/${id}`, 'DELETE');
    showToast('Record deleted', 'success');
    renderModule(name);
  } catch {
    showToast('Error deleting', 'error');
  }
}

function openModal()  { document.getElementById('modalOverlay').classList.add('open'); }
function closeModal() { document.getElementById('modalOverlay').classList.remove('open'); }

// ── API helper ─────────────────────────────────────────────────
async function apiFetch(url, method='GET', body=null) {
  const opts = { method, headers: {'Content-Type':'application/json'} };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(API + url, opts);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

// ── Toast ──────────────────────────────────────────────────────
function showToast(msg, type='') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `toast show ${type}`;
  setTimeout(() => t.classList.remove('show'), 3000);
}

// ── Badge helpers ──────────────────────────────────────────────
function badgeForYear(y) {
  const map = {'1':'badge-blue','2':'badge-teal','3':'badge-purple','4':'badge-orange'};
  return `<span class="badge ${map[y]||'badge-blue'}">Year ${esc(y||'1')}</span>`;
}
function attendanceBadge(s) {
  const map = {'Present':'badge-green','Absent':'badge-red','Late':'badge-orange'};
  return `<span class="badge ${map[s]||'badge-blue'}">${esc(s||'')}</span>`;
}
function feeStatusBadge(s) {
  const map = {'Paid':'badge-green','Pending':'badge-orange','Overdue':'badge-red'};
  return `<span class="badge ${map[s]||'badge-blue'}">${esc(s||'')}</span>`;
}
function gradeBadge(g) {
  const map = {'O':'badge-teal','A+':'badge-green','A':'badge-green','B+':'badge-blue','B':'badge-blue','C':'badge-orange','F':'badge-red'};
  return `<span class="badge ${map[g]||'badge-blue'}">${esc(g||'')}</span>`;
}
function priorityBadge(p) {
  const map = {'High':'badge-red','Medium':'badge-orange','Low':'badge-green'};
  return `<span class="badge ${map[p]||'badge-blue'}">${esc(p||'')}</span>`;
}
function noticeCatBadge(c) {
  return c ? `<span class="badge badge-purple">${esc(c)}</span>` : '';
}
function availabilityBadge(avail, total) {
  const a = parseInt(avail)||0, t = parseInt(total)||1;
  const cls = a === 0 ? 'badge-red' : a < t/2 ? 'badge-orange' : 'badge-green';
  return `<span class="badge ${cls}">${a}/${t} avail</span>`;
}

function colLabel(k, schema) {
  const f = schema.fields.find(f => f.k === k);
  return f ? f.l : capitalize(k.replace(/_/g,' '));
}

// ── Utilities ──────────────────────────────────────────────────
function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
function esc(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
