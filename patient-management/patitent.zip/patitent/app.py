from flask import Flask, render_template, request, jsonify
from pymongo import MongoClient
from bson.objectid import ObjectId
from datetime import datetime

app = Flask(__name__)

# Connect to MongoDB (Local)
client = MongoClient("mongodb://localhost:27017/")
db = client["hospital_db"]
patients_collection = db["patients"]

# Insert sample data if collection is empty
if patients_collection.count_documents({}) == 0:
    sample_patients = [
        {
            "name": "Alice Johnson",
            "age": 34,
            "disease": "Hypertension",
            "doctor": "Dr. Emily Brown",
            "visit_date": "2025-03-10"
        },
        {
            "name": "Bob Smith",
            "age": 56,
            "disease": "Type 2 Diabetes",
            "doctor": "Dr. Michael Lee",
            "visit_date": "2025-04-05"
        },
        {
            "name": "Carol Davis",
            "age": 29,
            "disease": "Asthma",
            "doctor": "Dr. Sarah Wilson",
            "visit_date": "2025-02-20"
        },
        {
            "name": "David Brown",
            "age": 67,
            "disease": "Arthritis",
            "doctor": "Dr. Robert Taylor",
            "visit_date": "2025-01-12"
        }
    ]
    patients_collection.insert_many(sample_patients)
    print("✅ Sample data inserted successfully!")

@app.route('/')
def index():
    return render_template('index.html')

# GET all patients
@app.route('/patients', methods=['GET'])
def get_patients():
    patients = list(patients_collection.find())
    for patient in patients:
        patient['_id'] = str(patient['_id'])
    return jsonify(patients)

# GET single patient by ID
@app.route('/patients/<string:patient_id>', methods=['GET'])
def get_patient(patient_id):
    try:
        patient = patients_collection.find_one({"_id": ObjectId(patient_id)})
        if patient:
            patient['_id'] = str(patient['_id'])
            return jsonify(patient)
        return jsonify({"error": "Patient not found"}), 404
    except:
        return jsonify({"error": "Invalid patient ID"}), 400

# POST - Add new patient
@app.route('/patients', methods=['POST'])
def add_patient():
    try:
        data = request.get_json()
        result = patients_collection.insert_one(data)
        return jsonify({
            "message": "Patient added successfully",
            "id": str(result.inserted_id)
        }), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# PUT - Update patient
@app.route('/patients/<string:patient_id>', methods=['PUT'])
def update_patient(patient_id):
    try:
        data = request.get_json()
        result = patients_collection.update_one(
            {"_id": ObjectId(patient_id)},
            {"$set": data}
        )
        if result.modified_count > 0:
            return jsonify({"message": "Patient updated successfully"})
        return jsonify({"error": "Patient not found"}), 404
    except:
        return jsonify({"error": "Invalid patient ID"}), 400

# DELETE - Delete patient
@app.route('/patients/<string:patient_id>', methods=['DELETE'])
def delete_patient(patient_id):
    try:
        result = patients_collection.delete_one({"_id": ObjectId(patient_id)})
        if result.deleted_count > 0:
            return jsonify({"message": "Patient deleted successfully"})
        return jsonify({"error": "Patient not found"}), 404
    except:
        return jsonify({"error": "Invalid patient ID"}), 400

if __name__ == '__main__':
    print("🚀 Hospital Patient Record System is starting...")
    print("🌐 Open your browser and go to: http://127.0.0.1:5000")
    print("📊 Sample data with 4 patients is already loaded!")
    app.run(debug=True)