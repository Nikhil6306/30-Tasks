from flask import Flask, render_template, request, jsonify
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime
from dotenv import load_dotenv
import os

load_dotenv()
app = Flask(__name__)

# ── MongoDB Connection ──────────────────────────────────────────
MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/")
client = MongoClient(MONGO_URI)
db = client["notes_platform"]
notes_col = db["notes"]


# ── Helper ──────────────────────────────────────────────────────
def serialize(note):
    note["_id"] = str(note["_id"])
    return note


# ── Routes ──────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")


# GET  /api/notes          – list all (with optional search & filter)
# POST /api/notes          – create
@app.route("/api/notes", methods=["GET", "POST"])
def notes():
    if request.method == "GET":
        query = {}
        search = request.args.get("search", "").strip()
        subject = request.args.get("subject", "").strip()
        if search:
            query["$or"] = [
                {"title":       {"$regex": search, "$options": "i"}},
                {"subject":     {"$regex": search, "$options": "i"}},
                {"topic":       {"$regex": search, "$options": "i"}},
                {"description": {"$regex": search, "$options": "i"}},
                {"author":      {"$regex": search, "$options": "i"}},
            ]
        if subject:
            query["subject"] = {"$regex": f"^{subject}$", "$options": "i"}

        sort = request.args.get("sort", "date")
        sort_field = {"date": "created_at", "title": "title", "subject": "subject"}.get(sort, "created_at")
        sort_dir   = -1 if sort == "date" else 1

        docs = list(notes_col.find(query).sort(sort_field, sort_dir))
        return jsonify([serialize(d) for d in docs])

    # POST – create
    data = request.get_json(force=True)
    required = ["title", "subject", "topic", "description", "author", "content_type", "content"]
    missing = [f for f in required if not data.get(f, "").strip()]
    if missing:
        return jsonify({"error": f"Missing fields: {', '.join(missing)}"}), 400

    doc = {
        "title":        data["title"].strip(),
        "subject":      data["subject"].strip(),
        "topic":        data["topic"].strip(),
        "description":  data["description"].strip(),
        "author":       data["author"].strip(),
        "content_type": data["content_type"].strip(),   # "text" | "link"
        "content":      data["content"].strip(),
        "created_at":   datetime.utcnow(),
    }
    result = notes_col.insert_one(doc)
    doc["_id"] = str(result.inserted_id)
    return jsonify(doc), 201


# GET    /api/notes/<id>   – single note
# PUT    /api/notes/<id>   – update
# DELETE /api/notes/<id>   – delete
@app.route("/api/notes/<note_id>", methods=["GET", "PUT", "DELETE"])
def note_detail(note_id):
    try:
        oid = ObjectId(note_id)
    except Exception:
        return jsonify({"error": "Invalid ID"}), 400

    doc = notes_col.find_one({"_id": oid})
    if not doc:
        return jsonify({"error": "Note not found"}), 404

    if request.method == "GET":
        return jsonify(serialize(doc))

    if request.method == "PUT":
        data = request.get_json(force=True)
        update = {k: data[k].strip() for k in
                  ["title", "subject", "topic", "description", "author", "content_type", "content"]
                  if k in data and data[k].strip()}
        update["updated_at"] = datetime.utcnow()
        notes_col.update_one({"_id": oid}, {"$set": update})
        doc = notes_col.find_one({"_id": oid})
        return jsonify(serialize(doc))

    # DELETE
    notes_col.delete_one({"_id": oid})
    return jsonify({"message": "Deleted successfully"})


# GET /api/subjects  – distinct subject list for filter dropdown
@app.route("/api/subjects")
def subjects():
    subjs = notes_col.distinct("subject")
    return jsonify(sorted(subjs))


# GET /api/stats
@app.route("/api/stats")
def stats():
    total      = notes_col.count_documents({})
    subjects   = len(notes_col.distinct("subject"))
    authors    = len(notes_col.distinct("author"))
    return jsonify({"total": total, "subjects": subjects, "authors": authors})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
