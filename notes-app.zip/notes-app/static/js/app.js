/* ── Utilities ──────────────────────────────────── */
const $ = id => document.getElementById(id);
const COLORS = [
  { bg: '#eef2ff', tx: '#3730a3' },
  { bg: '#d1fae5', tx: '#065f46' },
  { bg: '#fce7f3', tx: '#9d174d' },
  { bg: '#fef3c7', tx: '#92400e' },
  { bg: '#dbeafe', tx: '#1e40af' },
  { bg: '#f3e8ff', tx: '#6b21a8' },
  { bg: '#ffedd5', tx: '#9a3412' },
  { bg: '#dcfce7', tx: '#14532d' },
];
const subjectColorMap = {};
let colorIndex = 0;

function subjectColor(subj) {
  const key = subj.trim().toLowerCase();
  if (!subjectColorMap[key]) subjectColorMap[key] = COLORS[colorIndex++ % COLORS.length];
  return subjectColorMap[key];
}

function avatarColor(name) {
  let h = 0; for (const c of name) h = (h * 31 + c.charCodeAt(0)) % COLORS.length;
  return COLORS[h];
}

function initials(name) {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

function fmtDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function esc(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function showToast(msg, dur = 2400) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(t._t);
  t._t = setTimeout(() => t.classList.add('hidden'), dur);
}

/* ── State ──────────────────────────────────────── */
let currentViewId = null;
let deleteTargetId = null;
let debounceTimer = null;

/* ── API helpers ────────────────────────────────── */
async function apiFetch(url, opts = {}) {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

/* ── Load & Render ──────────────────────────────── */
async function loadNotes() {
  const search  = $('searchInput').value.trim();
  const subject = $('filterSubject').value;
  const sort    = $('sortBy').value;

  const params = new URLSearchParams();
  if (search)  params.set('search', search);
  if (subject) params.set('subject', subject);
  if (sort)    params.set('sort', sort);

  const grid = $('notesGrid');
  grid.innerHTML = '<div class="loading-state">Loading…</div>';

  try {
    const notes = await apiFetch(`/api/notes?${params}`);
    renderGrid(notes);
  } catch (e) {
    grid.innerHTML = `<div class="empty-state"><div class="empty-state-icon">⚠️</div>Could not load notes.<br><small>${esc(e.message)}</small></div>`;
  }
}

function renderGrid(notes) {
  const grid = $('notesGrid');
  if (!notes.length) {
    grid.innerHTML = '<div class="empty-state"><div class="empty-state-icon">📭</div>No notes found. Add your first note!</div>';
    return;
  }
  grid.innerHTML = notes.map(n => noteCard(n)).join('');
}

function noteCard(n) {
  const sc  = subjectColor(n.subject);
  const ac  = avatarColor(n.author);
  const link = n.content_type === 'link'
    ? `<a class="card-link" href="${esc(n.content)}" target="_blank" rel="noopener">🔗 View attachment</a>`
    : '';
  return `
  <article class="note-card" data-id="${n._id}">
    <div class="card-top">
      <div class="card-title">${esc(n.title)}</div>
      <span class="badge" style="background:${sc.bg};color:${sc.tx}">${esc(n.subject)}</span>
    </div>
    <div class="card-topic" style="color:${sc.tx}">📘 ${esc(n.topic)}</div>
    <div class="card-desc">${esc(n.description)}</div>
    ${link}
    <div class="card-footer">
      <div class="author-row">
        <div class="avatar" style="background:${ac.bg};color:${ac.tx}">${initials(n.author)}</div>
        <div>
          <div class="author-name">${esc(n.author)}</div>
          <div class="card-date">${fmtDate(n.created_at)}</div>
        </div>
      </div>
      <div class="card-actions">
        <button class="btn-icon" title="View"   onclick="openView('${n._id}')">👁</button>
        <button class="btn-icon" title="Edit"   onclick="openEdit('${n._id}')">✏️</button>
        <button class="btn-icon del" title="Delete" onclick="openDelete('${n._id}','${esc(n.title)}')">🗑</button>
      </div>
    </div>
  </article>`;
}

/* ── Stats & Subject filter ─────────────────────── */
async function loadStats() {
  try {
    const s = await apiFetch('/api/stats');
    $('statTotal').textContent    = s.total;
    $('statSubjects').textContent = s.subjects;
    $('statAuthors').textContent  = s.authors;
  } catch { /* silent */ }
}

async function loadSubjects() {
  try {
    const subs = await apiFetch('/api/subjects');
    const sel  = $('filterSubject');
    const cur  = sel.value;
    sel.innerHTML = '<option value="">All subjects</option>';
    subs.forEach(s => {
      const o = document.createElement('option');
      o.value = s; o.textContent = s;
      if (s === cur) o.selected = true;
      sel.appendChild(o);
    });

    // datalist for add form
    const dl = $('subjectList');
    if (dl) {
      dl.innerHTML = subs.map(s => `<option value="${esc(s)}"></option>`).join('');
    }
  } catch { /* silent */ }
}

/* ── Add / Edit Form ────────────────────────────── */
let activeType = 'text';

function setType(type) {
  activeType = type;
  document.querySelectorAll('.type-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.type === type);
  });
  const cf = $('contentField');
  if (type === 'link') {
    cf.innerHTML = `<label for="fContent">File link / URL <span class="req">*</span></label>
      <input type="url" id="fContent" placeholder="https://…" />`;
  } else {
    cf.innerHTML = `<label for="fContent">Note content <span class="req">*</span></label>
      <textarea id="fContent" rows="5" placeholder="Write your notes here…"></textarea>`;
  }
}

function openAdd() {
  $('editId').value   = '';
  $('modalTitle').textContent = 'Add Note';
  $('btnSubmitForm').textContent = 'Save note';
  $('noteForm').reset();
  setType('text');
  hideFormError();
  $('formOverlay').classList.remove('hidden');
  $('fTitle').focus();
}

async function openEdit(id) {
  try {
    const n = await apiFetch(`/api/notes/${id}`);
    $('editId').value = n._id;
    $('modalTitle').textContent = 'Edit Note';
    $('btnSubmitForm').textContent = 'Update note';
    $('fTitle').value   = n.title;
    $('fAuthor').value  = n.author;
    $('fSubject').value = n.subject;
    $('fTopic').value   = n.topic;
    $('fDesc').value    = n.description;
    setType(n.content_type);
    $('fContent').value = n.content;
    hideFormError();
    $('viewOverlay').classList.add('hidden');
    $('formOverlay').classList.remove('hidden');
    $('fTitle').focus();
  } catch (e) { showToast('Could not load note: ' + e.message); }
}

function hideFormError() {
  const el = $('formError');
  el.textContent = '';
  el.classList.add('hidden');
}

function showFormError(msg) {
  const el = $('formError');
  el.textContent = msg;
  el.classList.remove('hidden');
}

$('noteForm').addEventListener('submit', async e => {
  e.preventDefault();
  hideFormError();

  const payload = {
    title:        $('fTitle').value.trim(),
    author:       $('fAuthor').value.trim(),
    subject:      $('fSubject').value.trim(),
    topic:        $('fTopic').value.trim(),
    description:  $('fDesc').value.trim(),
    content_type: activeType,
    content:      $('fContent').value.trim(),
  };

  const missing = Object.entries(payload).filter(([,v]) => !v).map(([k]) => k);
  if (missing.length) {
    showFormError('Please fill all required fields: ' + missing.join(', '));
    return;
  }

  const btn = $('btnSubmitForm');
  btn.disabled = true;
  btn.textContent = 'Saving…';

  try {
    const id = $('editId').value;
    if (id) {
      await apiFetch(`/api/notes/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
      showToast('✅ Note updated successfully');
    } else {
      await apiFetch('/api/notes', { method: 'POST', body: JSON.stringify(payload) });
      showToast('✅ Note added successfully');
    }
    $('formOverlay').classList.add('hidden');
    await Promise.all([loadNotes(), loadStats(), loadSubjects()]);
  } catch (err) {
    showFormError(err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = id ? 'Update note' : 'Save note';
  }
});

document.querySelectorAll('.type-btn').forEach(b => {
  b.addEventListener('click', () => setType(b.dataset.type));
});

/* ── View Modal ─────────────────────────────────── */
async function openView(id) {
  currentViewId = id;
  try {
    const n  = await apiFetch(`/api/notes/${id}`);
    const sc = subjectColor(n.subject);
    const ac = avatarColor(n.author);

    $('viewTitle').textContent = n.title;

    const contentBlock = n.content_type === 'link'
      ? `<a href="${esc(n.content)}" target="_blank" rel="noopener" style="color:var(--primary);font-size:.9rem">🔗 ${esc(n.content)}</a>`
      : `<div class="view-content">${esc(n.content)}</div>`;

    $('viewBody').innerHTML = `
      <div class="view-tags">
        <span class="badge" style="background:${sc.bg};color:${sc.tx}">${esc(n.subject)}</span>
        <span class="view-tag">📘 ${esc(n.topic)}</span>
        <span class="view-tag">📅 ${fmtDate(n.created_at)}</span>
        ${n.updated_at ? `<span class="view-tag">✏️ Updated ${fmtDate(n.updated_at)}</span>` : ''}
      </div>
      <div class="view-field"><div class="view-label">Description</div>
        <div class="view-val">${esc(n.description)}</div></div>
      <div class="view-field"><div class="view-label">${n.content_type === 'link' ? 'Attachment' : 'Note content'}</div>
        ${contentBlock}</div>
      <div class="view-field"><div class="view-label">Author</div>
        <div class="view-author">
          <div class="avatar" style="background:${ac.bg};color:${ac.tx}">${initials(n.author)}</div>
          <span style="font-weight:600">${esc(n.author)}</span>
        </div>
      </div>`;

    $('viewOverlay').classList.remove('hidden');
  } catch (e) { showToast('Could not load note: ' + e.message); }
}

$('btnEditFromView').addEventListener('click', () => {
  if (currentViewId) openEdit(currentViewId);
});

/* ── Delete ─────────────────────────────────────── */
function openDelete(id, title) {
  deleteTargetId = id;
  $('deleteMsg').innerHTML = `Are you sure you want to delete <strong>${esc(title)}</strong>? This cannot be undone.`;
  $('deleteOverlay').classList.remove('hidden');
}

$('btnConfirmDelete').addEventListener('click', async () => {
  if (!deleteTargetId) return;
  try {
    await apiFetch(`/api/notes/${deleteTargetId}`, { method: 'DELETE' });
    showToast('🗑 Note deleted');
    $('deleteOverlay').classList.add('hidden');
    deleteTargetId = null;
    await Promise.all([loadNotes(), loadStats(), loadSubjects()]);
  } catch (e) { showToast('Delete failed: ' + e.message); }
});

/* ── Close handlers ─────────────────────────────── */
$('btnOpenAdd').addEventListener('click', openAdd);
$('btnCloseForm').addEventListener('click', () => $('formOverlay').classList.add('hidden'));
$('btnCancelForm').addEventListener('click', () => $('formOverlay').classList.add('hidden'));
$('btnCloseView').addEventListener('click', () => $('viewOverlay').classList.add('hidden'));
$('btnCloseView2').addEventListener('click', () => $('viewOverlay').classList.add('hidden'));
$('btnCloseDelete').addEventListener('click', () => $('deleteOverlay').classList.add('hidden'));
$('btnCancelDelete').addEventListener('click', () => $('deleteOverlay').classList.add('hidden'));

// Close on backdrop click
['formOverlay', 'viewOverlay', 'deleteOverlay'].forEach(id => {
  $(id).addEventListener('click', e => { if (e.target === $(id)) $(id).classList.add('hidden'); });
});

// Close on Escape
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    ['formOverlay', 'viewOverlay', 'deleteOverlay'].forEach(id => $(id).classList.add('hidden'));
  }
});

/* ── Search & filter ────────────────────────────── */
$('searchInput').addEventListener('input', () => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(loadNotes, 320);
});
$('filterSubject').addEventListener('change', loadNotes);
$('sortBy').addEventListener('change', loadNotes);

/* ── Boot ───────────────────────────────────────── */
(async () => {
  await Promise.all([loadNotes(), loadStats(), loadSubjects()]);
})();
