document.addEventListener('DOMContentLoaded', () => {
    const taskList = document.getElementById('taskList');
    const taskModal = document.getElementById('taskModal');
    const taskForm = document.getElementById('taskForm');
    const addTaskBtn = document.getElementById('addTaskBtn');
    const modalTitle = document.getElementById('modalTitle');
    const closeBtns = document.querySelectorAll('.close-btn');
    const filterBtns = document.querySelectorAll('.filter-btn');
    
    // Stats elements
    const totalTasksEl = document.getElementById('totalTasks');
    const pendingTasksEl = document.getElementById('pendingTasks');
    const completedTasksEl = document.getElementById('completedTasks');

    let allTasks = [];
    let currentFilter = 'all';

    // Fetch tasks on load
    fetchTasks();

    // Event Listeners
    addTaskBtn.addEventListener('click', () => openModal());
    
    closeBtns.forEach(btn => {
        btn.addEventListener('click', closeModal);
    });

    taskForm.addEventListener('submit', handleFormSubmit);

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentFilter = btn.dataset.filter;
            renderTasks();
        });
    });

    // Functions
    async function fetchTasks() {
        try {
            const response = await fetch('/api/tasks');
            allTasks = await response.json();
            renderTasks();
            updateStats();
        } catch (error) {
            console.error('Error fetching tasks:', error);
            taskList.innerHTML = '<p class="error">Failed to load tasks. Please ensure MongoDB is running.</p>';
        }
    }

    function renderTasks() {
        const filteredTasks = allTasks.filter(task => {
            if (currentFilter === 'all') return true;
            return task.status === currentFilter;
        });

        if (filteredTasks.length === 0) {
            taskList.innerHTML = `
                <div class="loading-state">
                    <i class="fas fa-clipboard-list"></i>
                    <p>No tasks found in this category.</p>
                </div>
            `;
            return;
        }

        taskList.innerHTML = filteredTasks.map(task => `
            <div class="task-card ${task.status === 'Completed' ? 'completed' : ''}" data-id="${task._id}">
                <div class="task-info">
                    <h3 class="task-title">${task.title}</h3>
                    <p class="task-desc">${task.description || 'No description'}</p>
                    <div class="task-meta">
                        <div class="meta-item">
                            <i class="far fa-calendar"></i>
                            <span>${formatDate(task.due_date)}</span>
                        </div>
                        <span class="status-badge ${task.status === 'Completed' ? 'status-completed' : 'status-pending'}">
                            ${task.status}
                        </span>
                    </div>
                </div>
                <div class="task-actions">
                    <button class="action-btn toggle-status" title="${task.status === 'Completed' ? 'Mark as Pending' : 'Mark as Completed'}">
                        <i class="fas ${task.status === 'Completed' ? 'fa-undo' : 'fa-check'}"></i>
                    </button>
                    <button class="action-btn edit" title="Edit Task">
                        <i class="fas fa-pen"></i>
                    </button>
                    <button class="action-btn delete" title="Delete Task">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');

        // Re-attach listeners to new elements
        attachTaskListeners();
    }

    function attachTaskListeners() {
        document.querySelectorAll('.toggle-status').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.target.closest('.task-card').dataset.id;
                const task = allTasks.find(t => t._id === id);
                toggleStatus(id, task.status);
            });
        });

        document.querySelectorAll('.edit').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.target.closest('.task-card').dataset.id;
                const task = allTasks.find(t => t._id === id);
                openModal(task);
            });
        });

        document.querySelectorAll('.delete').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.target.closest('.task-card').dataset.id;
                deleteTask(id);
            });
        });
    }

    async function handleFormSubmit(e) {
        e.preventDefault();
        const id = document.getElementById('taskId').value;
        const taskData = {
            title: document.getElementById('title').value,
            description: document.getElementById('description').value,
            due_date: document.getElementById('dueDate').value,
            status: id ? allTasks.find(t => t._id === id).status : 'Pending'
        };

        try {
            const url = id ? `/api/tasks/${id}` : '/api/tasks';
            const method = id ? 'PUT' : 'POST';
            
            const response = await fetch(url, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(taskData)
            });

            if (response.ok) {
                await fetchTasks();
                closeModal();
            }
        } catch (error) {
            console.error('Error saving task:', error);
        }
    }

    async function toggleStatus(id, currentStatus) {
        const newStatus = currentStatus === 'Pending' ? 'Completed' : 'Pending';
        try {
            const response = await fetch(`/api/tasks/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: newStatus })
            });
            if (response.ok) fetchTasks();
        } catch (error) {
            console.error('Error toggling status:', error);
        }
    }

    async function deleteTask(id) {
        if (!confirm('Are you sure you want to delete this task?')) return;
        try {
            const response = await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
            if (response.ok) fetchTasks();
        } catch (error) {
            console.error('Error deleting task:', error);
        }
    }

    function updateStats() {
        totalTasksEl.textContent = allTasks.length;
        pendingTasksEl.textContent = allTasks.filter(t => t.status === 'Pending').length;
        completedTasksEl.textContent = allTasks.filter(t => t.status === 'Completed').length;
    }

    function openModal(task = null) {
        taskModal.style.display = 'flex';
        if (task) {
            modalTitle.textContent = 'Edit Task';
            document.getElementById('taskId').value = task._id;
            document.getElementById('title').value = task.title;
            document.getElementById('description').value = task.description;
            document.getElementById('dueDate').value = task.due_date;
        } else {
            modalTitle.textContent = 'Create New Task';
            taskForm.reset();
            document.getElementById('taskId').value = '';
        }
    }

    function closeModal() {
        taskModal.style.display = 'none';
        taskForm.reset();
    }

    function formatDate(dateStr) {
        if (!dateStr) return 'No date';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' });
    }

    // Close modal when clicking outside
    window.onclick = (event) => {
        if (event.target === taskModal) closeModal();
    };
});
