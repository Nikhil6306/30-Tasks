# TaskMaster | Premium To-Do Manager

TaskMaster is a sophisticated, full-stack task management application designed with a focus on modern aesthetics and seamless user experience. It leverages **Flask** for the backend, **MongoDB** for data persistence, and a premium **Glassmorphism** design for the frontend.

## 🚀 Step-by-Step Setup Guide

Follow these instructions to get your TaskMaster application up and running locally.

### 1. Prerequisites
Ensure you have the following installed on your system:
- **Python 3.x**
- **MongoDB** (Ensure the MongoDB service is running)
- **pip** (Python package manager)

### 2. Install Dependencies
Open your terminal/command prompt in the project directory and run:
```bash
pip install flask pymongo
```

### 3. Database Configuration
By default, the application connects to MongoDB at `mongodb://localhost:27017/`.  
Ensure your MongoDB service is active. The application will automatically create the `todo_manager` database and `tasks` collection upon the first entry.

### 4. Run the Application
Start the Flask development server by running:
```bash
python app.py
```

### 5. Access TaskMaster
Once the server is running, open your web browser and navigate to:
[**http://127.0.0.1:5000**](http://127.0.0.1:5000)

---

## 🛠️ Features walkthrough
- **Add Tasks**: Click "New Task" to create a task with a title, description, and due date.
- **Track Status**: Tasks are marked as "Pending" by default. Check them off to mark as "Completed".
- **Real-time Filters**: Use the dashboard filters to see "All", "Pending", or "Completed" tasks.
- **Dashboard Stats**: Instantly see your progress with the built-in task counter.
- **Premium UI**: Experience smooth animations, glassmorphic cards, and a custom-generated background.

## 📂 Project Structure
- `app.py`: Backend Flask API and MongoDB handlers.
- `templates/index.html`: Main UI template.
- `static/css/style.css`: Premium design system.
- `static/js/script.js`: Frontend logic and API integration.
- `static/img/bg.png`: Custom high-resolution background asset.

---
*Created with ❤️ by TaskMaster Team*
