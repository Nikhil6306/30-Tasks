from flask import Flask, request, jsonify, render_template
import sqlite3
import os

app = Flask(__name__)
DB_FILE = 'main.sqlite'

def init_db():
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS courses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                code TEXT NOT NULL,
                credits INTEGER NOT NULL,
                instructor TEXT NOT NULL
            )
        ''')
        conn.commit()

# Initialize DB on startup
if not os.path.exists(DB_FILE):
    init_db()

def get_db_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/courses', methods=['GET'])
def get_courses():
    conn = get_db_connection()
    courses = conn.execute('SELECT * FROM courses').fetchall()
    conn.close()
    return jsonify([dict(ix) for ix in courses])

@app.route('/api/courses', methods=['POST'])
def add_course():
    data = request.get_json()
    name = data.get('name')
    code = data.get('code')
    credits = data.get('credits')
    instructor = data.get('instructor')

    if not all([name, code, credits, instructor]):
        return jsonify({'error': 'All fields are required'}), 400

    conn = get_db_connection()
    cursor = conn.execute(
        'INSERT INTO courses (name, code, credits, instructor) VALUES (?, ?, ?, ?)',
        (name, code, credits, instructor)
    )
    conn.commit()
    course_id = cursor.lastrowid
    conn.close()
    
    return jsonify({'id': course_id, 'name': name, 'code': code, 'credits': credits, 'instructor': instructor}), 201

@app.route('/api/courses/<int:id>', methods=['PUT'])
def update_course(id):
    data = request.get_json()
    name = data.get('name')
    code = data.get('code')
    credits = data.get('credits')
    instructor = data.get('instructor')

    if not all([name, code, credits, instructor]):
        return jsonify({'error': 'All fields are required'}), 400

    conn = get_db_connection()
    conn.execute(
        'UPDATE courses SET name = ?, code = ?, credits = ?, instructor = ? WHERE id = ?',
        (name, code, credits, instructor, id)
    )
    conn.commit()
    conn.close()
    
    return jsonify({'id': id, 'name': name, 'code': code, 'credits': credits, 'instructor': instructor})

@app.route('/api/courses/<int:id>', methods=['DELETE'])
def delete_course(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM courses WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Course deleted successfully'})

if __name__ == '__main__':
    # Ensure db table exists even if the file was created empty
    init_db()
    app.run(debug=True)
