# 🎓 College ERP System

A complete College ERP (Enterprise Resource Planning) System built using Flask, MongoDB, and modern frontend technologies to manage academic and administrative activities efficiently.

---

## 🚀 Technology Stack

- **Frontend:** HTML, CSS, JavaScript  
- **Backend:** Flask (Python)  
- **Database:** MongoDB  

---

## 📌 Features

The system includes multiple modules with full CRUD (Create, Read, Update, Delete) functionality:

### 👨‍🎓 Student Management
- Add, update, delete, and view student records

### 👩‍🏫 Teacher Management
- Manage teacher profiles and details

### 📚 Course Management
- Create and manage courses, duration, and trainers

### 📝 Attendance Management
- Record and track student attendance

### 💰 Fees Management
- Manage student fee details and payments

### 📊 Result Management
- Store and display student results

### 📢 Notice Board
- Post and manage important announcements

### 📖 Library Management
- Manage books, issue/return records

---

## 🖥️ Admin Dashboard

- Centralized dashboard to control all modules
- Easy navigation and management of records

---

## ⚙️ Installation Guide

### 1. Clone the repository
```bash
git clone https://github.com/your-username/college-erp.git
cd college-erp
```

### 2. Create Virtual Environment
```bash
python -m venv venv
venv\Scripts\activate   # Windows
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the Application
```bash
python app.py
```

---

## 📂 Project Structure

```
college-erp/
│── app.py
│── requirements.txt
│── README.md
│
├── templates/
├── static/
├── models/
├── routes/
```

---

## 🧩 CRUD Operations

Each module supports:
- Create new records
- Read/view records
- Update existing data
- Delete records

---

## 🎯 Future Enhancements

- Authentication (Login/Signup)
- Role-based access (Admin, Student, Teacher)
- API integration
- Deployment on cloud (Vercel/Render)

---

## 🤝 Contribution

Feel free to fork this repository and contribute.

---

## 📜 License

This project is open-source and free to use.

---

## 👨‍💻 Author

Developed by Nikhil Shukla
