document.addEventListener('DOMContentLoaded', () => {
    // UI Elements
    const courseGrid = document.getElementById('course-grid');
    const loadingState = document.getElementById('loading-state');
    const emptyState = document.getElementById('empty-state');
    
    // Stats Elements
    const statTotalCourses = document.getElementById('stat-total-courses');
    const statTotalCredits = document.getElementById('stat-total-credits');
    const statTotalInstructors = document.getElementById('stat-total-instructors');
    const searchInput = document.getElementById('search-input');

    // Modal Elements
    const courseModal = document.getElementById('course-modal');
    const deleteModal = document.getElementById('delete-modal');
    
    // Form Elements
    const courseForm = document.getElementById('course-form');
    const modalTitle = document.getElementById('modal-title');
    const courseIdInput = document.getElementById('course-id');
    const courseNameInput = document.getElementById('course-name');
    const courseCodeInput = document.getElementById('course-code');
    const courseCreditsInput = document.getElementById('course-credits');
    const courseInstructorInput = document.getElementById('course-instructor');
    
    // Buttons
    const addCourseBtn = document.getElementById('add-course-btn');
    const closeModalBtn = document.getElementById('close-modal');
    const cancelBtn = document.getElementById('cancel-btn');
    const cancelDeleteBtn = document.getElementById('cancel-delete-btn');
    const confirmDeleteBtn = document.getElementById('confirm-delete-btn');

    let courses = [];
    let currentDeleteId = null;

    // --- API Interactions ---
    async function fetchCourses() {
        showLoading();
        try {
            const response = await fetch('/api/courses');
            courses = await response.json();
            updateStats();
            renderCourses(courses);
        } catch (error) {
            console.error('Error fetching courses:', error);
            // Even on error, stop loading state
            renderCourses([]);
        }
    }

    async function saveCourse(courseData) {
        const isEdit = courseData.id !== '';
        const url = isEdit ? `/api/courses/${courseData.id}` : '/api/courses';
        const method = isEdit ? 'PUT' : 'POST';
        
        if (!isEdit) delete courseData.id;

        try {
            const response = await fetch(url, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(courseData)
            });
            
            if (response.ok) {
                closeModal();
                fetchCourses();
            }
        } catch (error) {
            console.error('Error saving course:', error);
        }
    }

    async function deleteCourse(id) {
        try {
            const response = await fetch(`/api/courses/${id}`, {
                method: 'DELETE'
            });
            if (response.ok) {
                closeDeleteModal();
                fetchCourses();
            }
        } catch (error) {
            console.error('Error deleting course:', error);
        }
    }

    // --- Analytics / Stats ---
    function updateStats() {
        statTotalCourses.innerText = courses.length;
        
        const totalCredits = courses.reduce((acc, curr) => acc + curr.credits, 0);
        statTotalCredits.innerText = totalCredits;
        
        const uniqueInstructors = new Set(courses.map(c => c.instructor)).size;
        statTotalInstructors.innerText = uniqueInstructors;
    }

    // --- Search Logic ---
    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        const filtered = courses.filter(c => 
            c.name.toLowerCase().includes(query) || 
            c.code.toLowerCase().includes(query) ||
            c.instructor.toLowerCase().includes(query)
        );
        renderCourses(filtered);
    });

    // --- Rendering ---
    function renderCourses(dataArray) {
        hideLoading();
        courseGrid.innerHTML = '';
        
        if (dataArray.length === 0 && searchInput.value.trim() === '') {
            emptyState.classList.remove('hidden');
            courseGrid.classList.add('hidden');
            return;
        }

        emptyState.classList.add('hidden');
        courseGrid.classList.remove('hidden');

        dataArray.forEach(course => {
            const card = document.createElement('div');
            card.className = 'course-card';
            card.innerHTML = `
                <div class="card-top">
                    <span class="card-badge">${course.code}</span>
                    <div class="card-actions">
                        <button class="action-icon edit-action" data-id="${course.id}">
                            <i class="fa-solid fa-pen"></i>
                        </button>
                        <button class="action-icon delete-action" data-id="${course.id}">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                </div>
                
                <div class="card-title">
                    <h3>${course.name}</h3>
                </div>
                
                <div class="card-meta">
                    <div class="meta-item" title="Credits">
                        <i class="fa-solid fa-star"></i>
                        <span>${course.credits} Credits</span>
                    </div>
                    <div class="meta-item" title="Instructor">
                        <i class="fa-solid fa-user-tie"></i>
                        <span>${course.instructor}</span>
                    </div>
                </div>
            `;
            courseGrid.appendChild(card);
        });

        // Attach dynamic listeners
        document.querySelectorAll('.edit-action').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.currentTarget.getAttribute('data-id');
                openEditModal(id);
            });
        });

        document.querySelectorAll('.delete-action').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = e.currentTarget.getAttribute('data-id');
                openDeleteModal(id);
            });
        });
    }

    function showLoading() {
        loadingState.classList.remove('hidden');
        emptyState.classList.add('hidden');
        courseGrid.classList.add('hidden');
    }

    function hideLoading() {
        loadingState.classList.add('hidden');
    }

    // --- Modal Management ---
    function openAddModal() {
        courseForm.reset();
        courseIdInput.value = '';
        modalTitle.textContent = 'Create New Course';
        courseModal.classList.add('active');
    }

    function openEditModal(id) {
        const course = courses.find(c => c.id == id);
        if (!course) return;

        courseIdInput.value = course.id;
        courseNameInput.value = course.name;
        courseCodeInput.value = course.code;
        courseCreditsInput.value = course.credits;
        courseInstructorInput.value = course.instructor;
        
        modalTitle.textContent = 'Edit Course';
        courseModal.classList.add('active');
    }

    function closeModal() { courseModal.classList.remove('active'); }
    function openDeleteModal(id) {
        currentDeleteId = id;
        deleteModal.classList.add('active');
    }
    function closeDeleteModal() {
        currentDeleteId = null;
        deleteModal.classList.remove('active');
    }

    // --- Listeners ---
    addCourseBtn.addEventListener('click', openAddModal);
    closeModalBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);
    
    // Outside click closes modal
    courseModal.addEventListener('click', (e) => { if (e.target === courseModal) closeModal(); });
    deleteModal.addEventListener('click', (e) => { if (e.target === deleteModal) closeDeleteModal(); });

    courseForm.addEventListener('submit', (e) => {
        e.preventDefault();
        saveCourse({
            id: courseIdInput.value,
            name: courseNameInput.value,
            code: courseCodeInput.value,
            credits: parseInt(courseCreditsInput.value),
            instructor: courseInstructorInput.value
        });
    });

    cancelDeleteBtn.addEventListener('click', closeDeleteModal);
    confirmDeleteBtn.addEventListener('click', () => {
        if (currentDeleteId) deleteCourse(currentDeleteId);
    });

    // Boot Up
    fetchCourses();
});
