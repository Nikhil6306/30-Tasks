from flask import Flask, render_template, request, jsonify
from pymongo import MongoClient
from bson.objectid import ObjectId
import json

app = Flask(__name__)

# MongoDB Configuration
# Replace with your connection string if using MongoDB Atlas
MONGO_URI = "mongodb://localhost:27017/"
client = MongoClient(MONGO_URI)
db = client['subscription_db']
subscriptions = db['plans']

@app.route('/')
def index():
    return render_template('index.html')

# API Endpoints for CRUD Operations

@app.route('/api/subscriptions', methods=['GET'])
def get_subscriptions():
    try:
        all_subs = list(subscriptions.find())
        for sub in all_subs:
            sub['_id'] = str(sub['_id'])
        return jsonify(all_subs)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/subscriptions', methods=['POST'])
def add_subscription():
    try:
        data = request.json
        new_sub = {
            "user_name": data.get('user_name'),
            "plan_name": data.get('plan_name'),
            "billing_cycle": data.get('billing_cycle'),
            "amount": float(data.get('amount')),
            "status": data.get('status', 'Active')
        }
        result = subscriptions.insert_one(new_sub)
        new_sub['_id'] = str(result.inserted_id)
        return jsonify(new_sub), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/api/subscriptions/<id>', methods=['PUT'])
def update_subscription(id):
    try:
        data = request.json
        update_data = {
            "user_name": data.get('user_name'),
            "plan_name": data.get('plan_name'),
            "billing_cycle": data.get('billing_cycle'),
            "amount": float(data.get('amount')),
            "status": data.get('status')
        }
        subscriptions.update_one({"_id": ObjectId(id)}, {"$set": update_data})
        return jsonify({"msg": "Updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/api/subscriptions/<id>', methods=['DELETE'])
def delete_subscription(id):
    try:
        subscriptions.delete_one({"_id": ObjectId(id)})
        return jsonify({"msg": "Deleted successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True, port=5001)
