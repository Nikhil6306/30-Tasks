document.addEventListener('DOMContentLoaded', () => {
    const subscriptionsList = document.getElementById('subscriptions-list');
    const subscriptionForm = document.getElementById('subscription-form');
    const modal = document.getElementById('subscription-modal');
    const addPlanBtn = document.getElementById('add-plan-btn');
    const closeModal = document.querySelector('.close-modal');
    const modalTitle = document.getElementById('modal-title');
    const subIdInput = document.getElementById('sub-id');

    // Stats elements
    const totalPlansCount = document.getElementById('total-plans-count');
    const totalMrr = document.getElementById('total-mrr');
    const activeUsersCount = document.getElementById('active-users-count');

    // Fetch and display subscriptions
    const fetchSubscriptions = async () => {
        try {
            const response = await fetch('/api/subscriptions');
            const data = await response.json();
            renderSubscriptions(data);
            updateStats(data);
        } catch (error) {
            console.error('Error fetching subscriptions:', error);
        }
    };

    const renderSubscriptions = (subs) => {
        subscriptionsList.innerHTML = '';
        subs.forEach(sub => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${sub.user_name}</td>
                <td>${sub.plan_name}</td>
                <td>${sub.billing_cycle}</td>
                <td>$${sub.amount.toFixed(2)}</td>
                <td><span class="status-badge status-${sub.status.toLowerCase()}">${sub.status}</span></td>
                <td class="actions-btns">
                    <button class="btn-icon edit-btn" data-id="${sub._id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-icon btn-delete delete-btn" data-id="${sub._id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            subscriptionsList.appendChild(tr);
        });

        // Add event listeners for edit and delete
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', () => handleEdit(btn.dataset.id, subs));
        });
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', () => handleDelete(btn.dataset.id));
        });
    };

    const updateStats = (subs) => {
        totalPlansCount.textContent = subs.length;
        const mrr = subs.reduce((acc, sub) => acc + sub.amount, 0);
        totalMrr.textContent = `$${mrr.toFixed(2)}`;
        const active = subs.filter(sub => sub.status === 'Active').length;
        activeUsersCount.textContent = active;
    };

    // Handle form submission (Create/Update)
    subscriptionForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = subIdInput.value;
        const formData = {
            user_name: document.getElementById('user_name').value,
            plan_name: document.getElementById('plan_name').value,
            billing_cycle: document.getElementById('billing_cycle').value,
            amount: document.getElementById('amount').value,
            status: document.getElementById('status').value
        };

        const method = id ? 'PUT' : 'POST';
        const url = id ? `/api/subscriptions/${id}` : '/api/subscriptions';

        try {
            const response = await fetch(url, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                closeModalFunc();
                fetchSubscriptions();
            }
        } catch (error) {
            console.error('Error saving subscription:', error);
        }
    });

    // Edit logic
    const handleEdit = (id, subs) => {
        const sub = subs.find(s => s._id === id);
        if (sub) {
            subIdInput.value = sub._id;
            document.getElementById('user_name').value = sub.user_name;
            document.getElementById('plan_name').value = sub.plan_name;
            document.getElementById('billing_cycle').value = sub.billing_cycle;
            document.getElementById('amount').value = sub.amount;
            document.getElementById('status').value = sub.status;
            
            modalTitle.textContent = 'Edit Subscription Plan';
            modal.style.display = 'block';
        }
    };

    // Delete logic
    const handleDelete = async (id) => {
        if (confirm('Are you sure you want to delete this subscription?')) {
            try {
                const response = await fetch(`/api/subscriptions/${id}`, {
                    method: 'DELETE'
                });
                if (response.ok) {
                    fetchSubscriptions();
                }
            } catch (error) {
                console.error('Error deleting subscription:', error);
            }
        }
    };

    // Modal UI logic
    const openModalFunc = () => {
        subscriptionForm.reset();
        subIdInput.value = '';
        modalTitle.textContent = 'Add Subscription Plan';
        modal.style.display = 'block';
    };

    const closeModalFunc = () => {
        modal.style.display = 'none';
    };

    addPlanBtn.addEventListener('click', openModalFunc);
    closeModal.addEventListener('click', closeModalFunc);
    window.addEventListener('click', (e) => {
        if (e.target == modal) closeModalFunc();
    });

    // Initial fetch
    fetchSubscriptions();
});
