from pymongo import MongoClient
import os
from datetime import datetime, timedelta
import random

def seed_database():
    MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
    client = MongoClient(MONGO_URI)
    db = client['ecommerce_db']

    # Clear existing data
    db.products.delete_many({})
    db.customers.delete_many({})
    db.orders.delete_many({})
    db.reviews.delete_many({})

    print("Seeding Products...")
    products = [
        {"name": "iPhone 15 Pro", "category": "Electronics", "price": 999.99, "stock": 50, "image_url": "https://images.unsplash.com/photo-1696446701796-da61225697cc?w=400"},
        {"name": "MacBook Air M2", "category": "Electronics", "price": 1199.00, "stock": 30, "image_url": "https://images.unsplash.com/photo-1611186871348-b1ca696452ca?w=400"},
        {"name": "Nike Air Max 270", "category": "Footwear", "price": 150.00, "stock": 100, "image_url": "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400"},
        {"name": "Sony WH-1000XM5", "category": "Audio", "price": 399.99, "stock": 45, "image_url": "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=400"},
        {"name": "Dyson V15 Detect", "category": "Home", "price": 749.99, "stock": 20, "image_url": "https://images.unsplash.com/photo-1558317374-067df5f15430?w=400"}
    ]
    product_ids = db.products.insert_many(products).inserted_ids

    print("Seeding Customers...")
    customers = [
        {"name": "John Doe", "email": "john@example.com", "phone": "123-456-7890", "address": "123 Main St, New York, NY"},
        {"name": "Jane Smith", "email": "jane@example.com", "phone": "987-654-3210", "address": "456 Oak Ave, Los Angeles, CA"},
        {"name": "Alice Johnson", "email": "alice@example.com", "phone": "555-0199", "address": "789 Pine Rd, Chicago, IL"}
    ]
    customer_ids = db.customers.insert_many(customers).inserted_ids

    print("Seeding Orders...")
    statuses = ['Pending', 'Processing', 'Shipped', 'Delivered']
    for i in range(10):
        cust_id = str(random.choice(customer_ids))
        prod_count = random.randint(1, 3)
        selected_prods = random.sample(list(db.products.find()), prod_count)
        total_price = sum(p['price'] for p in selected_prods)
        
        order = {
            "customer_id": cust_id,
            "product_ids": ", ".join([str(p['_id']) for p in selected_prods]),
            "total_price": round(total_price, 2),
            "status": random.choice(statuses),
            "date": (datetime.now() - timedelta(days=random.randint(0, 30))).strftime("%Y-%m-%d %H:%M:%S")
        }
        db.orders.insert_one(order)

    print("Seeding Reviews...")
    for pid in product_ids:
        for _ in range(random.randint(1, 4)):
            review = {
                "product_id": str(pid),
                "user_name": random.choice(["User123", "Shopper99", "TechLover", "ReviewerX"]),
                "rating": random.randint(3, 5),
                "comment": random.choice(["Great product!", "Fast shipping.", "Worth the money.", "Exceeded expectations.", "Excellent quality."]),
                "date": (datetime.now() - timedelta(days=random.randint(0, 10))).strftime("%Y-%m-%d %H:%M:%S")
            }
            db.reviews.insert_one(review)

    print("Seed complete!")

if __name__ == "__main__":
    seed_database()
