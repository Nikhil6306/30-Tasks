/* ────────────────────────────────────────────────────
   NexStore – E-Commerce Management JS
   ──────────────────────────────────────────────────── */

const API = '';   // same origin
let currentPage  = 'dashboard';
let editingId    = null;
let currentData  = { products:[], customers:[], orders:[], reviews:[] };

// ── Navigation ──────────────────────────────────────
function navigate(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById(`page-${page}`).classList.add('active');
  document.querySelector(`[data-page="${page}"]`).classList.add('active');

  const titles = { dashboard:'Dashboard', products:'Products', customers:'Customers', orders:'Orders', reviews:'Reviews' };
  document.getElementById('pageTitle').textContent = titles[page] || page;
  document.getElementById('addBtn').style.display  = page === 'dashboard' ? 'none' : 'inline-block';
  document.getElementById('globalSearch').value    = '';

  currentPage = page;
  if (page !== 'dashboard') loadPage(page);
  else loadStats();
}

// ── API Helpers ─────────────────────────────────────
async function apiFetch(url, options = {}) {
  const res = await fetch(API + url, {
    headers: { 'Content-Type': 'application/json' },
    ...options
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ── Stats ────────────────────────────────────────────
async function loadStats() {
  try {
    const s = await apiFetch('/api/stats');
    document.getElementById('stat-products').textContent  = s.products;
    document.getElementById('stat-customers').textContent = s.customers;
    document.getElementById('stat-orders').textContent    = s.orders;
    document.getElementById('stat-revenue').textContent   = `$${s.revenue.toLocaleString()}`;
    // apply accent colors per card
    const cards = document.querySelectorAll('.stat-card');
    const accents = ['#6c63ff','#f7c948','#3ecf8e','#ff6b6b'];
    cards.forEach((c,i) => {
      c.style.setProperty('--accent', accents[i]);
      c.querySelector('.stat-value').style.color = accents[i];
    });
  } catch(e) { console.error(e); }
}

// ── Load Page Data ───────────────────────────────────
async function loadPage(page, q = '') {
  const url = `/api/${page}` + (q ? `?q=${encodeURIComponent(q)}` : '');
  try {
    const data = await apiFetch(url);
    currentData[page] = data;
    renderPage(page, data);
  } catch(e) { showToast(e.message, true); }
}

function handleSearch(val) {
  if (currentPage !== 'dashboard') loadPage(currentPage, val);
}

// ── Render Functions ─────────────────────────────────
function renderPage(page, data) {
  const fns = { products: renderProducts, customers: renderCustomers, orders: renderOrders, reviews: renderReviews };
  fns[page]?.(data);
}

function renderProducts(data) {
  const el = document.getElementById('products-list');
  if (!data.length) { el.innerHTML = empty('▣', 'No products found'); return; }
  el.innerHTML = `
  <table>
    <thead><tr>
      <th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Description</th><th>Actions</th>
    </tr></thead>
    <tbody>
    ${data.map(p => `
      <tr>
        <td><strong>${esc(p.name)}</strong></td>
        <td>${esc(p.category)}</td>
        <td><strong>$${Number(p.price).toFixed(2)}</strong></td>
        <td>${p.stock < 10 ? `<span style="color:var(--red)">${p.stock}</span>` : p.stock}</td>
        <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--muted)">${esc(p.description||'')}</td>
        <td><div class="action-btns">
          <button class="btn-edit" onclick="openEdit('products','${p._id}')">Edit</button>
          <button class="btn-del"  onclick="deleteItem('products','${p._id}')">Delete</button>
        </div></td>
      </tr>`).join('')}
    </tbody>
  </table>`;
}

function renderCustomers(data) {
  const el = document.getElementById('customers-list');
  if (!data.length) { el.innerHTML = empty('◉', 'No customers found'); return; }
  el.innerHTML = `
  <table>
    <thead><tr>
      <th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th>Joined</th><th>Actions</th>
    </tr></thead>
    <tbody>
    ${data.map(c => `
      <tr>
        <td><strong>${esc(c.name)}</strong></td>
        <td style="color:var(--muted)">${esc(c.email)}</td>
        <td>${esc(c.phone)}</td>
        <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--muted)">${esc(c.address||'')}</td>
        <td style="color:var(--muted)">${fmtDate(c.created_at)}</td>
        <td><div class="action-btns">
          <button class="btn-edit" onclick="openEdit('customers','${c._id}')">Edit</button>
          <button class="btn-del"  onclick="deleteItem('customers','${c._id}')">Delete</button>
        </div></td>
      </tr>`).join('')}
    </tbody>
  </table>`;
}

function renderOrders(data) {
  const el = document.getElementById('orders-list');
  if (!data.length) { el.innerHTML = empty('◎', 'No orders found'); return; }
  el.innerHTML = `
  <table>
    <thead><tr>
      <th>Order ID</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Date</th><th>Actions</th>
    </tr></thead>
    <tbody>
    ${data.map(o => `
      <tr>
        <td style="font-family:monospace;font-size:11px;color:var(--muted)">#${o._id.slice(-6).toUpperCase()}</td>
        <td><strong>${esc(o.customer_name)}</strong></td>
        <td style="color:var(--muted)">${Array.isArray(o.items) ? o.items.map(i => `${i.product}×${i.qty}`).join(', ') : '—'}</td>
        <td><strong>$${Number(o.total_amount).toFixed(2)}</strong></td>
        <td><span class="badge badge-${(o.status||'pending').toLowerCase()}">${esc(o.status)}</span></td>
        <td style="color:var(--muted)">${fmtDate(o.created_at)}</td>
        <td><div class="action-btns">
          <button class="btn-edit" onclick="openEdit('orders','${o._id}')">Edit</button>
          <button class="btn-del"  onclick="deleteItem('orders','${o._id}')">Delete</button>
        </div></td>
      </tr>`).join('')}
    </tbody>
  </table>`;
}

function renderReviews(data) {
  const el = document.getElementById('reviews-list');
  if (!data.length) { el.innerHTML = empty('◇', 'No reviews found'); return; }
  el.innerHTML = `
  <table>
    <thead><tr>
      <th>Customer</th><th>Product</th><th>Rating</th><th>Comment</th><th>Date</th><th>Actions</th>
    </tr></thead>
    <tbody>
    ${data.map(r => `
      <tr>
        <td><strong>${esc(r.customer_name)}</strong></td>
        <td>${esc(r.product_name)}</td>
        <td><span class="stars">${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</span></td>
        <td style="max-width:250px">${esc(r.comment)}</td>
        <td style="color:var(--muted)">${fmtDate(r.created_at)}</td>
        <td><div class="action-btns">
          <button class="btn-del" onclick="deleteItem('reviews','${r._id}')">Delete</button>
        </div></td>
      </tr>`).join('')}
    </tbody>
  </table>`;
}

// ── Modal: Add / Edit ─────────────────────────────────
function openAddModal() {
  editingId = null;
  document.getElementById('modalTitle').textContent = `Add ${cap(currentPage.slice(0,-1))}`;
  document.getElementById('modalBody').innerHTML = getForm(currentPage, null);
  document.getElementById('modalOverlay').classList.add('open');
}

async function openEdit(page, id) {
  editingId = id;
  try {
    const item = await apiFetch(`/api/${page}/${id}`);
    document.getElementById('modalTitle').textContent = `Edit ${cap(page.slice(0,-1))}`;
    document.getElementById('modalBody').innerHTML     = getForm(page, item);
    document.getElementById('modalOverlay').classList.add('open');
  } catch(e) { showToast(e.message, true); }
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('open');
  editingId = null;
}

// ── Forms ─────────────────────────────────────────────
function getForm(page, d) {
  const v = (k, fb='') => esc(d?.[k] ?? fb);
  const forms = {
    products: `
      <div class="form-group"><label>Name *</label><input id="f_name" value="${v('name')}" placeholder="Product name"/></div>
      <div class="form-row">
        <div class="form-group"><label>Price *</label><input id="f_price" type="number" step=".01" value="${v('price')}" placeholder="0.00"/></div>
        <div class="form-group"><label>Stock *</label><input id="f_stock" type="number" value="${v('stock')}" placeholder="0"/></div>
      </div>
      <div class="form-group"><label>Category *</label>
        <select id="f_category">
          ${['Electronics','Footwear','Apparel','Appliances','Sports','Books','Beauty','Other'].map(c =>
            `<option value="${c}" ${v('category')===c?'selected':''}>${c}</option>`).join('')}
        </select>
      </div>
      <div class="form-group"><label>Description</label><textarea id="f_description" placeholder="Brief description…">${v('description')}</textarea></div>`,

    customers: `
      <div class="form-group"><label>Full Name *</label><input id="f_name" value="${v('name')}" placeholder="John Doe"/></div>
      <div class="form-group"><label>Email *</label><input id="f_email" type="email" value="${v('email')}" placeholder="john@example.com"/></div>
      <div class="form-row">
        <div class="form-group"><label>Phone *</label><input id="f_phone" value="${v('phone')}" placeholder="555-0100"/></div>
        <div class="form-group"><label>City</label><input id="f_city" value="${v('city')}" placeholder="New York"/></div>
      </div>
      <div class="form-group"><label>Address</label><textarea id="f_address" placeholder="Street address…">${v('address')}</textarea></div>`,

    orders: `
      <div class="form-group"><label>Customer Name *</label><input id="f_customer_name" value="${v('customer_name')}" placeholder="Customer name"/></div>
      <div class="form-group"><label>Customer ID</label><input id="f_customer_id" value="${v('customer_id')}" placeholder="Customer ObjectId (optional)"/></div>
      <div class="form-group"><label>Items (JSON)</label>
        <textarea id="f_items" placeholder='[{"product":"Name","qty":1,"price":9.99}]'>${d?.items ? JSON.stringify(d.items) : ''}</textarea>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Total Amount *</label><input id="f_total_amount" type="number" step=".01" value="${v('total_amount')}" placeholder="0.00"/></div>
        <div class="form-group"><label>Status</label>
          <select id="f_status">
            ${['Pending','Processing','Shipped','Delivered','Cancelled'].map(s =>
              `<option value="${s}" ${v('status')===s?'selected':''}>${s}</option>`).join('')}
          </select>
        </div>
      </div>`,

    reviews: `
      <div class="form-group"><label>Customer Name *</label><input id="f_customer_name" value="${v('customer_name')}" placeholder="Customer name"/></div>
      <div class="form-group"><label>Product Name *</label><input id="f_product_name" value="${v('product_name')}" placeholder="Product name"/></div>
      <div class="form-group"><label>Rating *</label>
        <select id="f_rating">
          ${[1,2,3,4,5].map(r => `<option value="${r}" ${Number(v('rating',5))===r?'selected':''}>${r} Star${r>1?'s':''}</option>`).join('')}
        </select>
      </div>
      <div class="form-group"><label>Comment *</label><textarea id="f_comment" placeholder="Share your experience…">${v('comment')}</textarea></div>`
  };
  return (forms[page]||'') + `
    <div class="modal-actions">
      <button class="btn-cancel" onclick="closeModal()">Cancel</button>
      <button class="btn-save" onclick="saveItem('${page}')">Save</button>
    </div>`;
}

// ── Save ─────────────────────────────────────────────
async function saveItem(page) {
  const g = id => document.getElementById(id)?.value?.trim();
  let body = {};

  if (page === 'products') {
    if (!g('f_name')||!g('f_price')||!g('f_stock')) return showToast('Name, Price and Stock are required', true);
    body = { name:g('f_name'), price:g('f_price'), stock:g('f_stock'), category:g('f_category'), description:g('f_description') };
  } else if (page === 'customers') {
    if (!g('f_name')||!g('f_email')||!g('f_phone')) return showToast('Name, Email and Phone are required', true);
    body = { name:g('f_name'), email:g('f_email'), phone:g('f_phone'), city:g('f_city'), address:g('f_address') };
  } else if (page === 'orders') {
    if (!g('f_customer_name')||!g('f_total_amount')) return showToast('Customer Name and Total are required', true);
    let items = [];
    try { if (g('f_items')) items = JSON.parse(g('f_items')); } catch(e) { return showToast('Items must be valid JSON', true); }
    body = { customer_name:g('f_customer_name'), customer_id:g('f_customer_id')||'', items, total_amount:g('f_total_amount'), status:g('f_status') };
  } else if (page === 'reviews') {
    if (!g('f_customer_name')||!g('f_product_name')||!g('f_comment')) return showToast('All review fields are required', true);
    body = { customer_name:g('f_customer_name'), product_name:g('f_product_name'), rating:g('f_rating'), comment:g('f_comment') };
  }

  try {
    if (editingId) {
      await apiFetch(`/api/${page}/${editingId}`, { method:'PUT', body:JSON.stringify(body) });
      showToast(`${cap(page.slice(0,-1))} updated!`);
    } else {
      await apiFetch(`/api/${page}`, { method:'POST', body:JSON.stringify(body) });
      showToast(`${cap(page.slice(0,-1))} added!`);
    }
    closeModal();
    loadPage(page);
  } catch(e) { showToast(e.message, true); }
}

// ── Delete ───────────────────────────────────────────
async function deleteItem(page, id) {
  if (!confirm('Are you sure you want to delete this item?')) return;
  try {
    await apiFetch(`/api/${page}/${id}`, { method:'DELETE' });
    showToast(`${cap(page.slice(0,-1))} deleted`);
    loadPage(page);
    loadStats();
  } catch(e) { showToast(e.message, true); }
}

// ── Seed ─────────────────────────────────────────────
async function seedData() {
  try {
    await apiFetch('/api/seed', { method:'POST' });
    showToast('Sample data loaded!');
    if (currentPage !== 'dashboard') loadPage(currentPage);
    else loadStats();
  } catch(e) { showToast(e.message, true); }
}

// ── Utils ─────────────────────────────────────────────
function esc(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
function fmtDate(d) {
  if (!d) return '—';
  try { return new Date(d).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' }); }
  catch { return d; }
}
function empty(icon, msg) {
  return `<div class="empty-state"><span>${icon}</span>${msg}</div>`;
}
function showToast(msg, err = false) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast' + (err ? ' error' : '') + ' show';
  t.style.borderLeftColor = err ? 'var(--red)' : 'var(--green)';
  setTimeout(() => t.classList.remove('show'), 3000);
}

// ── Init ─────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  loadStats();
  document.getElementById('addBtn').style.display = 'none';
});
