document.addEventListener('DOMContentLoaded', () => {
    let currentSection = 'dashboard';
    let editId = null;

    const sections = {
        dashboard: {
            title: 'Dashboard Overview',
            desc: 'Key metrics and recent activity',
            btn: null
        },
        products: {
            title: 'Product Management',
            desc: 'Manage your inventory and product listings',
            btn: 'Add Product',
            columns: ['Image', 'Name', 'Category', 'Price', 'Stock', 'Actions'],
            fields: [
                { name: 'name', label: 'Product Name', type: 'text', required: true },
                { name: 'category', label: 'Category', type: 'text', required: true },
                { name: 'price', label: 'Price ($)', type: 'number', step: '0.01', required: true },
                { name: 'stock', label: 'Stock Quantity', type: 'number', required: true },
                { name: 'image_url', label: 'Image URL', type: 'url', placeholder: 'https://example.com/image.jpg' }
            ]
        },
        customers: {
            title: 'Customer Management',
            desc: 'View and manage your customer database',
            btn: 'Add Customer',
            columns: ['Name', 'Email', 'Phone', 'Address', 'Actions'],
            fields: [
                { name: 'name', label: 'Full Name', type: 'text', required: true },
                { name: 'email', label: 'Email Address', type: 'email', required: true },
                { name: 'phone', label: 'Phone Number', type: 'tel' },
                { name: 'address', label: 'Shipping Address', type: 'textarea' }
            ]
        },
        orders: {
            title: 'Order Tracking',
            desc: 'Monitor and process customer orders',
            btn: 'Create Order',
            columns: ['Order ID', 'Date', 'Customer ID', 'Total', 'Status', 'Actions'],
            fields: [
                { name: 'customer_id', label: 'Customer ID', type: 'text', required: true },
                { name: 'product_ids', label: 'Product IDs (comma separated)', type: 'text', required: true },
                { name: 'total_price', label: 'Total Price ($)', type: 'number', step: '0.01', required: true },
                { name: 'status', label: 'Status', type: 'select', options: ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'] }
            ]
        },
        reviews: {
            title: 'Product Reviews',
            desc: 'Manage customer feedback and ratings',
            btn: 'Add Review',
            columns: ['Product ID', 'User', 'Rating', 'Comment', 'Date', 'Actions'],
            fields: [
                { name: 'product_id', label: 'Product ID', type: 'text', required: true },
                { name: 'user_name', label: 'User Name', type: 'text', required: true },
                { name: 'rating', label: 'Rating (1-5)', type: 'number', min: 1, max: 5, required: true },
                { name: 'comment', label: 'Comment', type: 'textarea', required: true }
            ]
        }
    };

    // DOM Elements
    const tableHead = document.getElementById('table-head');
    const tableBody = document.getElementById('table-body');
    const sectionTitle = document.getElementById('section-title');
    const sectionDesc = document.getElementById('section-desc');
    const addBtn = document.getElementById('add-btn');
    const btnText = document.getElementById('btn-text');
    const modal = document.getElementById('modal');
    const modalTitle = document.getElementById('modal-title');
    const mainForm = document.getElementById('main-form');
    const saveBtn = document.getElementById('save-btn');
    const closeModal = document.getElementById('close-modal');
    const navLinks = document.querySelectorAll('.nav-link');
    const dashboardView = document.getElementById('dashboard-view');
    const tableView = document.getElementById('table-view');
    const dbStatus = document.getElementById('db-status');

    async function checkDBStatus() {
        try {
            const res = await fetch('/api/health');
            const data = await res.json();
            if (data.status === 'online') {
                dbStatus.className = 'db-status online';
                dbStatus.querySelector('.status-text').innerText = 'Database Online';
            } else {
                dbStatus.className = 'db-status offline';
                dbStatus.querySelector('.status-text').innerText = 'Database Offline';
            }
        } catch (err) {
            dbStatus.className = 'db-status offline';
            dbStatus.querySelector('.status-text').innerText = 'Server Error';
        }
    }

    // Navigation Initialization
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            currentSection = link.dataset.section;
            renderUI();
        });
    });

    async function fetchData() {
        try {
            const res = await fetch(`/api/${currentSection}`);
            if (!res.ok) throw new Error('Failed to fetch');
            return await res.json();
        } catch (err) {
            showToast('Error fetching data: ' + err.message, 'danger');
            return [];
        }
    }

    async function fetchStats() {
        try {
            const res = await fetch('/api/stats');
            if (!res.ok) throw new Error('Stats unavailable');
            return await res.json();
        } catch (err) {
            console.error('Error fetching stats:', err);
            return null;
        }
    }

    async function renderUI() {
        const config = sections[currentSection];
        if (!config) return;
        
        sectionTitle.innerText = config.title;
        sectionDesc.innerText = config.desc;

        if (config.btn) {
            addBtn.style.display = 'flex';
            btnText.innerText = config.btn;
        } else {
            addBtn.style.display = 'none';
        }

        if (currentSection === 'dashboard') {
            dashboardView.style.display = 'grid';
            tableView.style.display = 'none';
            renderDashboard();
        } else {
            dashboardView.style.display = 'none';
            tableView.style.display = 'block';
            renderTable();
        }
        
        checkDBStatus();
    }

    // Periodically check DB status every 10 seconds
    setInterval(checkDBStatus, 10000);

    async function renderDashboard() {
        dashboardView.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 2rem;">Loading dashboard metrics...</div>';
        const stats = await fetchStats();
        if (!stats) {
            dashboardView.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 2rem; color: var(--danger);">Failed to load stats.</div>';
            return;
        }

        dashboardView.innerHTML = `
            <div class="stat-card">
                <div class="stat-icon icon-blue"><i class="fas fa-box"></i></div>
                <div class="stat-info">
                    <h3>Total Products</h3>
                    <div class="value">${stats.total_products}</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-green"><i class="fas fa-users"></i></div>
                <div class="stat-info">
                    <h3>Total Customers</h3>
                    <div class="value">${stats.total_customers}</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-orange"><i class="fas fa-shopping-cart"></i></div>
                <div class="stat-info">
                    <h3>Total Orders</h3>
                    <div class="value">${stats.total_orders}</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-purple"><i class="fas fa-dollar-sign"></i></div>
                <div class="stat-info">
                    <h3>Total Revenue</h3>
                    <div class="value">$${stats.total_revenue}</div>
                </div>
            </div>
        `;
    }

    async function renderTable() {
        const config = sections[currentSection];
        // Render Head
        tableHead.innerHTML = `<tr>${config.columns.map(col => `<th>${col}</th>`).join('')}</tr>`;

        // Fetch & Render Body
        tableBody.innerHTML = '<tr><td colspan="100%" style="text-align:center">Loading data...</td></tr>';
        const data = await fetchData();
        tableBody.innerHTML = '';

        if (data.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="100%" style="text-align:center">No records found</td></tr>';
            return;
        }

        data.forEach(item => {
            const tr = document.createElement('tr');
            let cells = '';

            if (currentSection === 'products') {
                cells = `
                    <td><img src="${item.image_url || 'https://via.placeholder.com/40'}" style="width:40px;height:40px;border-radius:8px;object-fit:cover"></td>
                    <td>${item.name}</td>
                    <td><span class="badge badge-warning">${item.category}</span></td>
                    <td>$${parseFloat(item.price).toFixed(2)}</td>
                    <td>${item.stock}</td>
                `;
            } else if (currentSection === 'customers') {
                cells = `
                    <td>${item.name}</td>
                    <td>${item.email}</td>
                    <td>${item.phone || '-'}</td>
                    <td>${item.address || '-'}</td>
                `;
            } else if (currentSection === 'orders') {
                const statusClass = item.status === 'Delivered' ? 'badge-success' : (item.status === 'Cancelled' ? 'badge-danger' : 'badge-warning');
                cells = `
                    <td><code>#${item._id.slice(-6).toUpperCase()}</code></td>
                    <td style="font-size:0.8rem">${item.date}</td>
                    <td>${item.customer_id}</td>
                    <td>$${parseFloat(item.total_price).toFixed(2)}</td>
                    <td><span class="badge ${statusClass}">${item.status}</span></td>
                `;
            } else if (currentSection === 'reviews') {
                cells = `
                    <td>${item.product_id}</td>
                    <td>${item.user_name}</td>
                    <td><span style="color:var(--warning)"><i class="fas fa-star"></i> ${item.rating}</span></td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${item.comment}</td>
                    <td style="font-size:0.8rem">${item.date}</td>
                `;
            }

            cells += `
                <td>
                    <div class="action-btns">
                        <button class="btn-icon btn-edit" onclick="openEditModal('${item._id}')" title="Edit"><i class="fas fa-edit"></i></button>
                        <button class="btn-icon btn-delete" onclick="deleteItem('${item._id}')" title="Delete"><i class="fas fa-trash"></i></button>
                    </div>
                </td>
            `;
            tr.innerHTML = cells;
            tableBody.appendChild(tr);
        });
    }

    // Modal Handling
    addBtn.onclick = () => {
        console.log('Add button clicked. Section:', currentSection);
        editId = null;
        const config = sections[currentSection];
        if (!config || !config.btn) {
            console.warn('No add configuration for current section');
            return;
        }
        modalTitle.innerText = config.btn;
        renderForm();
        modal.style.display = 'flex';
    };

    closeModal.onclick = () => {
        modal.style.display = 'none';
    };

    function renderForm(data = null) {
        const fields = sections[currentSection].fields;
        if (!fields) {
            console.warn('No fields defined for section:', currentSection);
            return;
        }
        mainForm.innerHTML = fields.map(f => {
            const val = data ? data[f.name] : '';
            if (f.type === 'textarea') {
                return `
                    <div class="form-group">
                        <label>${f.label}</label>
                        <textarea name="${f.name}" ${f.required ? 'required' : ''}>${val}</textarea>
                    </div>
                `;
            } else if (f.type === 'select') {
                return `
                    <div class="form-group">
                        <label>${f.label}</label>
                        <select name="${f.name}">
                            ${f.options.map(opt => `<option value="${opt}" ${val === opt ? 'selected' : ''}>${opt}</option>`).join('')}
                        </select>
                    </div>
                `;
            }
            return `
                <div class="form-group">
                    <label>${f.label}</label>
                    <input type="${f.type}" name="${f.name}" value="${val}" ${f.step ? `step="${f.step}"` : ''} ${f.min !== undefined ? `min="${f.min}"` : ''} ${f.max !== undefined ? `max="${f.max}"` : ''} ${f.placeholder ? `placeholder="${f.placeholder}"` : ''} ${f.required ? 'required' : ''}>
                </div>
            `;
        }).join('');
    }

    window.openEditModal = async (id) => {
        editId = id;
        const data = await fetchData();
        const item = data.find(i => i._id === id);
        modalTitle.innerText = `Edit ${currentSection.slice(0, -1)}`;
        renderForm(item);
        modal.style.display = 'flex';
    };

    saveBtn.onclick = async () => {
        const formData = new FormData(mainForm);
        const data = Object.fromEntries(formData.entries());
        
        // Convert numbers
        const fields = sections[currentSection].fields;
        fields.forEach(f => {
            if (f.type === 'number' && data[f.name]) {
                data[f.name] = f.step ? parseFloat(data[f.name]) : parseInt(data[f.name]);
            }
        });

        const method = editId ? 'PUT' : 'POST';
        const url = editId ? `/api/${currentSection}/${editId}` : `/api/${currentSection}`;

        try {
            const res = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            if (res.ok) {
                showToast(`Success! ${currentSection.slice(0, -1)} ${editId ? 'updated' : 'added'}.`, 'success');
                modal.style.display = 'none';
                renderUI();
            } else {
                const errData = await res.json();
                showToast(errData.message || 'Save failed', 'danger');
            }
        } catch (err) {
            showToast('Save failed: ' + err.message, 'danger');
        }
    };

    window.deleteItem = async (id) => {
        if (!confirm('Are you sure you want to delete this?')) return;
        try {
            const res = await fetch(`/api/${currentSection}/${id}`, { method: 'DELETE' });
            if (res.ok) {
                showToast('Successfully deleted', 'success');
                renderUI();
            }
        } catch (err) {
            showToast('Delete failed', 'danger');
        }
    };

    function showToast(msg, type) {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerText = msg;
        document.getElementById('toast-container').appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }

    renderUI();
});
