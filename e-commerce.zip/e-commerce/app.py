from flask import Flask, render_template, request, jsonify
from pymongo import MongoClient
from bson import ObjectId
from flask_cors import CORS
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)

# MongoDB Configuration
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
# Add timeouts and connection pooling
client = MongoClient(
    MONGO_URI, 
    serverSelectionTimeoutMS=2000, 
    connectTimeoutMS=2000,
    retryWrites=True
)
db = client['ecommerce_db']

# Collections
products_col = db['products']
customers_col = db['customers']
orders_col = db['orders']
reviews_col = db['reviews']

def serialize_doc(doc):
    if doc:
        doc['_id'] = str(doc['_id'])
    return doc

def serialize_docs(docs):
    return [serialize_doc(doc) for doc in docs]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/health', methods=['GET'])
def health_check():
    try:
        client.admin.command('ping')
        return jsonify({"status": "online", "message": "Database connected"})
    except Exception as e:
        return jsonify({"status": "offline", "message": str(e)}), 503

@app.route('/api/stats', methods=['GET'])
def get_stats():
    try:
        total_products = products_col.count_documents({})
        total_customers = customers_col.count_documents({})
        total_orders = orders_col.count_documents({})
        
        orders = list(orders_col.find())
        total_revenue = sum(float(order.get('total_price', 0)) for order in orders)
        
        return jsonify({
            "total_products": total_products,
            "total_customers": total_customers,
            "total_orders": total_orders,
            "total_revenue": round(total_revenue, 2)
        })
    except Exception:
        return jsonify({"error": "Database error"}), 500

# --- PRODUCTS CRUD ---
@app.route('/api/products', methods=['GET'])
def get_products():
    products = list(products_col.find())
    return jsonify(serialize_docs(products))

@app.route('/api/products', methods=['POST'])
def add_product():
    data = request.json
    result = products_col.insert_one(data)
    return jsonify({"message": "Product added", "id": str(result.inserted_id)}), 201

@app.route('/api/products/<id>', methods=['PUT'])
def update_product(id):
    data = request.json
    products_col.update_one({'_id': ObjectId(id)}, {'$set': data})
    return jsonify({"message": "Product updated"})

@app.route('/api/products/<id>', methods=['DELETE'])
def delete_product(id):
    products_col.delete_one({'_id': ObjectId(id)})
    return jsonify({"message": "Product deleted"})

# --- CUSTOMERS CRUD ---
@app.route('/api/customers', methods=['GET'])
def get_customers():
    customers = list(customers_col.find())
    return jsonify(serialize_docs(customers))

@app.route('/api/customers', methods=['POST'])
def add_customer():
    data = request.json
    result = customers_col.insert_one(data)
    return jsonify({"message": "Customer added", "id": str(result.inserted_id)}), 201

@app.route('/api/customers/<id>', methods=['PUT'])
def update_customer(id):
    data = request.json
    customers_col.update_one({'_id': ObjectId(id)}, {'$set': data})
    return jsonify({"message": "Customer updated"})

@app.route('/api/customers/<id>', methods=['DELETE'])
def delete_customer(id):
    customers_col.delete_one({'_id': ObjectId(id)})
    return jsonify({"message": "Customer deleted"})

# --- ORDERS CRUD ---
@app.route('/api/orders', methods=['GET'])
def get_orders():
    orders = list(orders_col.find())
    return jsonify(serialize_docs(orders))

@app.route('/api/orders', methods=['POST'])
def add_order():
    data = request.json
    data['date'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    result = orders_col.insert_one(data)
    return jsonify({"message": "Order placed", "id": str(result.inserted_id)}), 201

@app.route('/api/orders/<id>', methods=['PUT'])
def update_order(id):
    data = request.json
    orders_col.update_one({'_id': ObjectId(id)}, {'$set': data})
    return jsonify({"message": "Order updated"})

@app.route('/api/orders/<id>', methods=['DELETE'])
def delete_order(id):
    orders_col.delete_one({'_id': ObjectId(id)})
    return jsonify({"message": "Order deleted"})

# --- REVIEWS CRUD ---
@app.route('/api/reviews', methods=['GET'])
def get_reviews():
    reviews = list(reviews_col.find())
    return jsonify(serialize_docs(reviews))

@app.route('/api/reviews', methods=['POST'])
def add_review():
    data = request.json
    data['date'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    result = reviews_col.insert_one(data)
    return jsonify({"message": "Review added", "id": str(result.inserted_id)}), 201

@app.route('/api/reviews/<id>', methods=['PUT'])
def update_review(id):
    data = request.json
    reviews_col.update_one({'_id': ObjectId(id)}, {'$set': data})
    return jsonify({"message": "Review updated"})

@app.route('/api/reviews/<id>', methods=['DELETE'])
def delete_review(id):
    reviews_col.delete_one({'_id': ObjectId(id)})
    return jsonify({"message": "Review deleted"})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
