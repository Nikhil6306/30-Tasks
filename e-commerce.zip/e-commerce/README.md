# NexStore — E-Commerce Management System

A full-stack e-commerce management system built with **Flask**, **MongoDB**, and vanilla **HTML/CSS/JS**.

---

## Tech Stack

| Layer     | Technology               |
|-----------|--------------------------|
| Frontend  | HTML5, CSS3, JavaScript  |
| Backend   | Python / Flask           |
| Database  | MongoDB                  |

---

## Features

- **Products** – Add, view, edit, delete products with category, price, stock, description
- **Customers** – Manage customer profiles (name, email, phone, address)
- **Orders** – Track orders with status (Pending / Processing / Shipped / Delivered / Cancelled)
- **Reviews** – Collect and display product reviews with star ratings
- **Dashboard** – Real-time stats (total products, customers, orders, revenue)
- **Search** – Live search across all sections
- **Sample Data** – One-click seed to populate the database for demo

---

## Setup & Run

### 1. Prerequisites
- Python 3.8+
- MongoDB running locally (`mongodb://localhost:27017/`) **or** a MongoDB Atlas URI

### 2. Install dependencies
```bash
cd ecommerce
pip install -r requirements.txt
```

### 3. Configure MongoDB (optional)
By default the app connects to `mongodb://localhost:27017/`.
To use a custom URI set the environment variable:
```bash
export MONGO_URI="mongodb+srv://user:password@cluster.mongodb.net/"
```

### 4. Run the server
```bash
python app.py
```

### 5. Open in browser
```
http://localhost:5000
```

Click **⚡ Load Sample Data** in the sidebar to pre-populate the database.

---

## API Endpoints

| Method | Endpoint              | Description          |
|--------|-----------------------|----------------------|
| GET    | /api/stats            | Dashboard statistics |
| GET    | /api/products         | List all products    |
| POST   | /api/products         | Create product       |
| PUT    | /api/products/:id     | Update product       |
| DELETE | /api/products/:id     | Delete product       |
| GET    | /api/customers        | List all customers   |
| POST   | /api/customers        | Create customer      |
| PUT    | /api/customers/:id    | Update customer      |
| DELETE | /api/customers/:id    | Delete customer      |
| GET    | /api/orders           | List all orders      |
| POST   | /api/orders           | Create order         |
| PUT    | /api/orders/:id       | Update order         |
| DELETE | /api/orders/:id       | Delete order         |
| GET    | /api/reviews          | List all reviews     |
| POST   | /api/reviews          | Create review        |
| DELETE | /api/reviews/:id      | Delete review        |
| POST   | /api/seed             | Seed sample data     |

---

## Project Structure

```
ecommerce/
├── app.py               # Flask backend & all API routes
├── requirements.txt     # Python dependencies
├── README.md
├── templates/
│   └── index.html       # Single-page frontend template
└── static/
    ├── css/
    │   └── style.css    # Complete UI styles
    └── js/
        └── app.js       # Frontend logic & CRUD operations
```
