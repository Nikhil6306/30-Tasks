from flask import Flask, render_template, request, jsonify
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

# MongoDB Configuration
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
client = MongoClient(MONGO_URI)
db = client['ticket_db']
tickets_collection = db['tickets']

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/tickets', methods=['GET'])
def get_tickets():
    tickets = list(tickets_collection.find())
    for ticket in tickets:
        ticket['_id'] = str(ticket['_id'])
    return jsonify(tickets)

@app.route('/api/tickets', methods=['POST'])
def create_ticket():
    data = request.json
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    new_ticket = {
        "title": data.get("title"),
        "category": data.get("category"),
        "description": data.get("description"),
        "status": data.get("status", "Open"),
        "submission_date": datetime.now().isoformat()
    }
    
    result = tickets_collection.insert_one(new_ticket)
    new_ticket['_id'] = str(result.inserted_id)
    return jsonify(new_ticket), 201

@app.route('/api/tickets/<id>', methods=['PUT'])
def update_ticket(id):
    data = request.json
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    update_data = {}
    if "title" in data: update_data["title"] = data["title"]
    if "category" in data: update_data["category"] = data["category"]
    if "description" in data: update_data["description"] = data["description"]
    if "status" in data: update_data["status"] = data["status"]

    result = tickets_collection.update_one({"_id": ObjectId(id)}, {"$set": update_data})
    
    if result.matched_count == 0:
        return jsonify({"error": "Ticket not found"}), 404
        
    return jsonify({"message": "Ticket updated successfully"})

@app.route('/api/tickets/<id>', methods=['DELETE'])
def delete_ticket(id):
    result = tickets_collection.delete_one({"_id": ObjectId(id)})
    if result.deleted_count == 0:
        return jsonify({"error": "Ticket not found"}), 404
    return jsonify({"message": "Ticket deleted successfully"})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
