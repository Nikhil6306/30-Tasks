document.addEventListener('DOMContentLoaded', () => {
    const ticketForm = document.getElementById('ticket-form');
    const ticketModal = document.getElementById('ticket-modal');
    const openNewTicketBtn = document.getElementById('open-new-ticket');
    const closeModalBtns = document.querySelectorAll('.close-modal');
    const recentTicketsBody = document.getElementById('recent-tickets-body');
    const searchInput = document.getElementById('search-input');
    const sidebarItems = document.querySelectorAll('.sidebar ul li');

    let allTickets = [];

    // Initialize
    fetchTickets();

    // Event Listeners
    openNewTicketBtn.addEventListener('click', () => {
        openModal();
    });

    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            ticketModal.style.display = 'none';
        });
    });

    ticketForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await saveTicket();
    });

    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        renderTickets(allTickets.filter(t => 
            t.title.toLowerCase().includes(query) || 
            t.description.toLowerCase().includes(query) ||
            t.category.toLowerCase().includes(query)
        ));
    });

    sidebarItems.forEach(item => {
        item.addEventListener('click', () => {
            sidebarItems.forEach(i => i.classList.remove('active'));
            item.classList.add('active');
            // Logic for switching views could go here if more views are added
        });
    });

    // Functions
    async function fetchTickets() {
        try {
            const response = await fetch('/api/tickets');
            allTickets = await response.json();
            renderTickets(allTickets);
            updateStats(allTickets);
        } catch (error) {
            console.error('Error fetching tickets:', error);
            showToast('Failed to load tickets', 'error');
        }
    }

    function renderTickets(tickets) {
        recentTicketsBody.innerHTML = '';
        
        // Sort by date descending
        const sortedTickets = [...tickets].sort((a, b) => new Date(b.submission_date) - new Date(a.submission_date));

        sortedTickets.forEach(ticket => {
            const date = new Date(ticket.submission_date).toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric'
            });

            const row = document.createElement('tr');
            row.innerHTML = `
                <td>#${ticket._id.substring(ticket._id.length - 4)}</td>
                <td><strong>${ticket.title}</strong></td>
                <td>${ticket.category}</td>
                <td>${date}</td>
                <td><span class="status-badge ${ticket.status.toLowerCase().replace(' ', '-')}">${ticket.status}</span></td>
                <td class="actions">
                    <button class="edit-btn" data-id="${ticket._id}" title="Edit"><i class="fas fa-edit"></i></button>
                    <button class="delete-btn" data-id="${ticket._id}" title="Delete"><i class="fas fa-trash"></i></button>
                </td>
            `;
            recentTicketsBody.appendChild(row);

            // Add events to new buttons
            row.querySelector('.edit-btn').addEventListener('click', () => openModal(ticket));
            row.querySelector('.delete-btn').addEventListener('click', () => deleteTicket(ticket._id));
        });
    }

    async function saveTicket() {
        const id = document.getElementById('ticket-id').value;
        const ticketData = {
            title: document.getElementById('title').value,
            category: document.getElementById('category').value,
            description: document.getElementById('description').value,
            status: document.getElementById('status').value
        };

        const method = id ? 'PUT' : 'POST';
        const url = id ? `/api/tickets/${id}` : '/api/tickets';

        try {
            const response = await fetch(url, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(ticketData)
            });

            if (response.ok) {
                showToast(id ? 'Ticket updated successfully' : 'Ticket submitted successfully', 'success');
                ticketModal.style.display = 'none';
                fetchTickets();
            } else {
                showToast('Failed to save ticket', 'error');
            }
        } catch (error) {
            console.error('Error saving ticket:', error);
            showToast('An error occurred', 'error');
        }
    }

    async function deleteTicket(id) {
        if (!confirm('Are you sure you want to delete this ticket?')) return;

        try {
            const response = await fetch(`/api/tickets/${id}`, { method: 'DELETE' });
            if (response.ok) {
                showToast('Ticket deleted', 'success');
                fetchTickets();
            } else {
                showToast('Failed to delete ticket', 'error');
            }
        } catch (error) {
            console.error('Error deleting ticket:', error);
        }
    }

    function openModal(ticket = null) {
        ticketForm.reset();
        document.getElementById('ticket-id').value = ticket ? ticket._id : '';
        document.getElementById('modal-title').textContent = ticket ? 'Update Ticket' : 'Create New Ticket';
        document.getElementById('submit-btn').textContent = ticket ? 'Update Ticket' : 'Submit Ticket';
        document.getElementById('status-group').style.display = ticket ? 'block' : 'none';

        if (ticket) {
            document.getElementById('title').value = ticket.title;
            document.getElementById('category').value = ticket.category;
            document.getElementById('description').value = ticket.description;
            document.getElementById('status').value = ticket.status;
        }

        ticketModal.style.display = 'flex';
    }

    function updateStats(tickets) {
        const stats = {
            open: tickets.filter(t => t.status === 'Open').length,
            progress: tickets.filter(t => t.status === 'In Progress').length,
            resolved: tickets.filter(t => t.status === 'Resolved').length
        };

        document.getElementById('stat-open').textContent = stats.open;
        document.getElementById('stat-progress').textContent = stats.progress;
        document.getElementById('stat-resolved').textContent = stats.resolved;
    }

    function showToast(message, type = 'success') {
        // Simple alert for now, could be replaced with a proper toast notification system
        // alert(message);
        console.log(`[${type}] ${message}`);
        // Let's implement a quick toast
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.style.cssText = `
            position: fixed; bottom: 20px; right: 20px; 
            padding: 12px 24px; border-radius: 8px; color: white;
            background-color: ${type === 'success' ? '#10b981' : '#ef4444'};
            box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            z-index: 1000; transition: all 0.5s ease;
        `;
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 500);
        }, 3000);
    }
});
