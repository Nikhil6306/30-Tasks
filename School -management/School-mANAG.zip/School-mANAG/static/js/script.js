document.addEventListener('DOMContentLoaded', () => {
    const feeForm = document.getElementById('feeForm');
    const feeTableBody = document.getElementById('feeTableBody');
    const noData = document.getElementById('noData');
    const stats = document.getElementById('stats');

    // Fetch and render records
    async function fetchFees() {
        try {
            const response = await fetch('/api/fees');
            const fees = await response.json();
            renderFees(fees);
        } catch (error) {
            showToast('Error fetching records', 'error');
        }
    }

    function renderFees(fees) {
        feeTableBody.innerHTML = '';
        if (fees.length === 0) {
            noData.style.display = 'block';
            stats.innerText = '0 Records';
            return;
        }

        noData.style.display = 'none';
        stats.innerText = `${fees.length} Records Found`;

        fees.forEach(fee => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>
                    <div style="font-weight: 500;">${fee.student_name}</div>
                </td>
                <td>${fee.class_name}</td>
                <td style="font-weight: 600;">$${fee.amount}</td>
                <td>${new Date(fee.due_date).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}</td>
                <td>
                    <span class="status-badge status-${fee.status.toLowerCase()}">${fee.status}</span>
                </td>
                <td>
                    <div class="actions">
                        <button class="action-btn" onclick="updateStatus('${fee._id}', '${fee.status}')" title="Update Status">
                            🔄
                        </button>
                        <button class="action-btn delete-btn" onclick="deleteRecord('${fee._id}')" title="Delete Record">
                            🗑️
                        </button>
                    </div>
                </td>
            `;
            feeTableBody.appendChild(tr);
        });
    }

    // Handle Form Submission
    feeForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = {
            student_name: document.getElementById('studentName').value,
            class_name: document.getElementById('className').value,
            amount: document.getElementById('amount').value,
            due_date: document.getElementById('dueDate').value,
            status: document.getElementById('status').value
        };

        try {
            const response = await fetch('/api/fees', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                showToast('Record saved successfully!', 'success');
                feeForm.reset();
                fetchFees();
            } else {
                showToast('Failed to save record', 'error');
            }
        } catch (error) {
            showToast('Network error', 'error');
        }
    });

    // Global functions for actions
    window.updateStatus = async (id, currentStatus) => {
        const statuses = ['Unpaid', 'Pending', 'Paid'];
        const nextIndex = (statuses.indexOf(currentStatus) + 1) % statuses.length;
        const newStatus = statuses[nextIndex];

        try {
            const response = await fetch(`/api/fees/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: newStatus })
            });

            if (response.ok) {
                showToast(`Status updated to ${newStatus}`, 'success');
                fetchFees();
            }
        } catch (error) {
            showToast('Update failed', 'error');
        }
    };

    const deleteModal = document.getElementById('deleteModal');
    const confirmDeleteBtn = document.getElementById('confirmDelete');
    const cancelDeleteBtn = document.getElementById('cancelDelete');
    let recordToDelete = null;

    window.deleteRecord = (id) => {
        recordToDelete = id;
        deleteModal.classList.add('active');
    };

    confirmDeleteBtn.addEventListener('click', async () => {
        if (!recordToDelete) return;

        try {
            const response = await fetch(`/api/fees/${recordToDelete}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                showToast('Record deleted', 'success');
                fetchFees();
            }
        } catch (error) {
            showToast('Delete failed', 'error');
        } finally {
            closeDeleteModal();
        }
    });

    cancelDeleteBtn.addEventListener('click', closeDeleteModal);
    
    function closeDeleteModal() {
        deleteModal.classList.remove('active');
        recordToDelete = null;
    }

    function showToast(message, type) {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerText = message;
        container.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // Initial load
    fetchFees();
});
