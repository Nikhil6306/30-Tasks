# 🎓 EduPay Pro - School Fee Management System

EduPay Pro is a modern, full-stack web application designed to help schools manage student fee records efficiently. Built with **Flask** and **MongoDB**, it features a beautiful glassmorphic UI and full CRUD (Create, Read, Update, Delete) capabilities.

---

## 🚀 Key Features

*   **✨ Premium Design**: A modern, dark-themed dashboard with glassmorphism effects.
*   **➕ Add Records**: Easily add student fee details including name, class, amount, and due date.
*   **📊 Dynamic Table**: View all records in a responsive table with status badges.
*   **🔄 Instant Updates**: Cycle through payment statuses (Unpaid, Pending, Paid) with a single click.
*   **🗑️ Safe Deletions**: Custom deletion modal to prevent accidental data loss.
*   **🔔 Real-time Notifications**: Toast notifications for immediate feedback on every action.

---

## 🛠️ Technology Stack

*   **Frontend**: HTML5, CSS3 (Vanilla), JavaScript (ES6+)
*   **Backend**: Python, Flask
*   **Database**: MongoDB

---

## 📥 Getting Started (For Beginners)

Follow these steps to get the project running on your local machine:

### 1. Prerequisites
Make sure you have the following installed:
*   [Python 3.x](https://www.python.org/downloads/)
*   [MongoDB Community Server](https://www.mongodb.com/try/download/community)

### 2. Setup Database
Ensure your MongoDB server is running. By default, the app looks for a connection at `mongodb://localhost:27017/`.

### 3. Install Dependencies
Open your terminal (Command Prompt or PowerShell) in the project folder and run:
```bash
pip install -r requirements.txt
```

### 4. Run the Application
Start the Flask server by running:
```bash
python app.py
```

### 5. Access the App
Open your web browser and go to:
`http://localhost:5000`

---

## 📂 Project Structure

```bash
School-mANAG/
├── static/
│   ├── css/
│   │   └── style.css    # Premium dashboard styles
│   └── js/
│       └── script.js   # Frontend logic and API calls
├── templates/
│   └── index.html      # Main HTML structure
├── app.py              # Flask server and MongoDB logic
├── requirements.txt    # List of required Python packages
└── README.md           # This guide!
```

---

## 💡 Troubleshooting

*   **MongoDB Connection Error**: Ensure the MongoDB service is started on your computer.
*   **Port 5000 already in use**: If the app fails to start, another program might be using port 5000. You can change the port in `app.py` by editing `app.run(port=5000)`.

---

## 📜 License
This project is for educational purposes. Feel free to use and modify it!
