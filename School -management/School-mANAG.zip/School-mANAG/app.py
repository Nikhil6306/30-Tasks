from flask import Flask, render_template, request, jsonify
from pymongo import MongoClient
from bson.objectid import ObjectId
from datetime import datetime
import os

app = Flask(__name__)

# MongoDB Configuration
# Try to get MONGO_URI from env, default to localhost
mongo_uri = os.environ.get("MONGO_URI", "mongodb://localhost:27017/")
client = MongoClient(mongo_uri)
db = client['school_fee_db']
fees_collection = db['fees']

def serialize_doc(doc):
    if doc and '_id' in doc:
        doc['_id'] = str(doc['_id'])
    return doc

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/fees', methods=['GET'])
def get_fees():
    try:
        fees = list(fees_collection.find().sort("created_at", -1))
        return jsonify([serialize_doc(f) for f in fees])
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/fees', methods=['POST'])
def add_fee():
    try:
        data = request.json
        new_record = {
            "student_name": data.get("student_name"),
            "class_name": data.get("class_name"),
            "amount": data.get("amount"),
            "due_date": data.get("due_date"),
            "status": data.get("status", "Unpaid"),
            "created_at": datetime.now()
        }
        result = fees_collection.insert_one(new_record)
        new_record['_id'] = str(result.inserted_id)
        # Convert datetime to string for JSON response
        new_record['created_at'] = new_record['created_at'].isoformat()
        return jsonify(new_record), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/fees/<id>', methods=['PUT'])
def update_fee(id):
    try:
        data = request.json
        fees_collection.update_one({"_id": ObjectId(id)}, {"$set": {"status": data.get("status")}})
        return jsonify({"message": "Updated successfully"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/fees/<id>', methods=['DELETE'])
def delete_fee(id):
    try:
        fees_collection.delete_one({"_id": ObjectId(id)})
        return jsonify({"message": "Deleted successfully"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
