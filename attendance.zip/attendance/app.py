from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime
import os

app = Flask(__name__, static_folder='static')
CORS(app)

# MongoDB connection
MONGO_URI = os.environ.get('MONGO_URI', 'mongodb://localhost:27017/')
client = MongoClient(MONGO_URI)
db = client['attendance_db']
collection = db['attendance']

def serialize(doc):
    doc['_id'] = str(doc['_id'])
    return doc

# ─── CREATE ───────────────────────────────────────────────────────────────────
@app.route('/api/attendance', methods=['POST'])
def add_attendance():
    data = request.get_json()
    required = ['student_name', 'date', 'subject', 'status']
    if not all(k in data for k in required):
        return jsonify({'error': 'Missing required fields'}), 400

    record = {
        'student_name': data['student_name'].strip(),
        'date': data['date'],
        'subject': data['subject'].strip(),
        'status': data['status'],  # 'present' | 'absent' | 'late'
        'created_at': datetime.utcnow().isoformat()
    }
    result = collection.insert_one(record)
    record['_id'] = str(result.inserted_id)
    return jsonify(record), 201

# ─── READ ALL ──────────────────────────────────────────────────────────────────
@app.route('/api/attendance', methods=['GET'])
def get_all_attendance():
    query = {}
    student = request.args.get('student_name')
    subject = request.args.get('subject')
    status  = request.args.get('status')
    date    = request.args.get('date')

    if student: query['student_name'] = {'$regex': student, '$options': 'i'}
    if subject: query['subject']      = {'$regex': subject, '$options': 'i'}
    if status:  query['status']       = status
    if date:    query['date']         = date

    records = [serialize(r) for r in collection.find(query).sort('date', -1)]
    return jsonify(records), 200

# ─── READ ONE ─────────────────────────────────────────────────────────────────
@app.route('/api/attendance/<id>', methods=['GET'])
def get_attendance(id):
    try:
        record = collection.find_one({'_id': ObjectId(id)})
    except Exception:
        return jsonify({'error': 'Invalid ID'}), 400
    if not record:
        return jsonify({'error': 'Record not found'}), 404
    return jsonify(serialize(record)), 200

# ─── UPDATE ───────────────────────────────────────────────────────────────────
@app.route('/api/attendance/<id>', methods=['PUT'])
def update_attendance(id):
    data = request.get_json()
    try:
        oid = ObjectId(id)
    except Exception:
        return jsonify({'error': 'Invalid ID'}), 400

    allowed = ['student_name', 'date', 'subject', 'status']
    update = {k: data[k] for k in allowed if k in data}
    if not update:
        return jsonify({'error': 'No valid fields to update'}), 400

    result = collection.update_one({'_id': oid}, {'$set': update})
    if result.matched_count == 0:
        return jsonify({'error': 'Record not found'}), 404

    updated = serialize(collection.find_one({'_id': oid}))
    return jsonify(updated), 200

# ─── DELETE ───────────────────────────────────────────────────────────────────
@app.route('/api/attendance/<id>', methods=['DELETE'])
def delete_attendance(id):
    try:
        oid = ObjectId(id)
    except Exception:
        return jsonify({'error': 'Invalid ID'}), 400

    result = collection.delete_one({'_id': oid})
    if result.deleted_count == 0:
        return jsonify({'error': 'Record not found'}), 404
    return jsonify({'message': 'Record deleted successfully'}), 200

# ─── STATS ────────────────────────────────────────────────────────────────────
@app.route('/api/stats', methods=['GET'])
def get_stats():
    total   = collection.count_documents({})
    present = collection.count_documents({'status': 'present'})
    absent  = collection.count_documents({'status': 'absent'})
    late    = collection.count_documents({'status': 'late'})
    students = len(collection.distinct('student_name'))
    subjects = len(collection.distinct('subject'))
    return jsonify({
        'total': total, 'present': present,
        'absent': absent, 'late': late,
        'students': students, 'subjects': subjects
    }), 200

# ─── SERVE FRONTEND ───────────────────────────────────────────────────────────
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

if __name__ == '__main__':
    app.run(debug=True, port=5000)
