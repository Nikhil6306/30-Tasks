# 🏋️ Gym Membership Management System

## 📌 Project Overview
The **Gym Membership Management System** is a web-based application developed using **Flask**, **MongoDB**, and **Frontend technologies (HTML, CSS, JavaScript)**.  
It allows users to efficiently manage gym member records through CRUD operations.

---

## 🚀 Features
- ➕ Add new gym members
- 📋 View all members
- ✏️ Update membership details
- ❌ Delete member records

---

## 🛠️ Tech Stack
- **Frontend:** HTML, CSS, JavaScript  
- **Backend:** Flask (Python)  
- **Database:** MongoDB  

---

## 📊 Member Details
Each gym member record includes:
- Name  
- Age  
- Membership Plan  
- Joining Date  
- Trainer Name  

---

## 🔄 CRUD Operations
### ➤ Create
Add new members to the system.

### ➤ Read
View all registered members.

### ➤ Update
Modify existing member details.

### ➤ Delete
Remove member records from the database.

---

## ⚙️ Installation & Setup

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/gym-management.git
cd gym-management
```

### 2. Create Virtual Environment
```bash
python -m venv venv
source venv/bin/activate   # For Linux/Mac
venv\Scripts\activate    # For Windows
```

### 3. Install Dependencies
```bash
pip install flask pymongo
```

### 4. Run the Application
```bash
python app.py
```

---

## 🌐 Project Structure
```
gym-management/
│── app.py
│── templates/
│── static/
│── requirements.txt
│── README.md
```

---

## 📌 Future Enhancements
- User authentication system
- Membership payment tracking
- Dashboard with analytics

---

## 👨‍💻 Author
Nikhil Shukla

---

## 📎 GitHub
https://github.com/Nikhil6306
