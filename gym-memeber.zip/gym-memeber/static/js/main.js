document.addEventListener('DOMContentLoaded', () => {
    const membersGrid = document.getElementById('membersGrid');
    const searchInput = document.getElementById('searchInput');
    const addMemberBtn = document.getElementById('addMemberBtn');
    const memberModal = document.getElementById('memberModal');
    const closeModal = document.getElementById('closeModal');
    const memberForm = document.getElementById('memberForm');
    const modalTitle = document.getElementById('modalTitle');
    
    let allMembers = [];

    // Fetch and display members
    const fetchMembers = async () => {
        try {
            const response = await fetch('/api/members');
            allMembers = await response.json();
            renderMembers(allMembers);
        } catch (error) {
            console.error('Error fetching members:', error);
            membersGrid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: var(--danger);">Failed to load members. Is MongoDB running?</p>';
        }
    };

    const renderMembers = (members) => {
        if (members.length === 0) {
            membersGrid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: var(--text-muted); padding: 3rem;">No members found.</p>';
            return;
        }

        membersGrid.innerHTML = members.map(member => `
            <div class="member-card">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
                    <h3>${member.name}</h3>
                    <span class="badge badge-${member.plan.toLowerCase()}">${member.plan}</span>
                </div>
                <div class="member-info">
                    <div class="info-row">
                        <span class="info-label">Age</span>
                        <span class="info-value">${member.age}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Trainer</span>
                        <span class="info-value">${member.trainer}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Joined</span>
                        <span class="info-value">${member.joining_date}</span>
                    </div>
                </div>
                <div class="card-actions">
                    <button class="btn-icon" onclick="editMember('${member._id}')" title="Edit Member">
                        <i class="ph ph-pencil-simple-line"></i>
                    </button>
                    <button class="btn-icon btn-delete" onclick="deleteMember('${member._id}')" title="Delete Member">
                        <i class="ph ph-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
    };

    // Modal logic
    const openModal = (member = null) => {
        if (member) {
            modalTitle.innerText = 'Edit Member';
            document.getElementById('memberId').value = member._id;
            document.getElementById('name').value = member.name;
            document.getElementById('age').value = member.age;
            document.getElementById('plan').value = member.plan;
            document.getElementById('trainer').value = member.trainer;
            document.getElementById('joining_date').value = member.joining_date;
        } else {
            modalTitle.innerText = 'Add New Member';
            memberForm.reset();
            document.getElementById('memberId').value = '';
            document.getElementById('joining_date').value = new Date().toISOString().split('T')[0];
        }
        memberModal.style.display = 'flex';
    };

    addMemberBtn.addEventListener('click', () => openModal());
    closeModal.addEventListener('click', () => memberModal.style.display = 'none');
    window.addEventListener('click', (e) => {
        if (e.target === memberModal) memberModal.style.display = 'none';
    });

    // Handle Form Submit (Add/Update)
    memberForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('memberId').value;
        const memberData = {
            name: document.getElementById('name').value,
            age: document.getElementById('age').value,
            plan: document.getElementById('plan').value,
            trainer: document.getElementById('trainer').value,
            joining_date: document.getElementById('joining_date').value
        };

        const method = id ? 'PUT' : 'POST';
        const url = id ? `/api/members/${id}` : '/api/members';

        try {
            const response = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(memberData)
            });

            if (response.ok) {
                memberModal.style.display = 'none';
                fetchMembers();
            }
        } catch (error) {
            console.error('Error saving member:', error);
        }
    });

    // Delete member
    window.deleteMember = async (id) => {
        if (confirm('Are you sure you want to delete this member?')) {
            try {
                const response = await fetch(`/api/members/${id}`, { method: 'DELETE' });
                if (response.ok) fetchMembers();
            } catch (error) {
                console.error('Error deleting member:', error);
            }
        }
    };

    // Edit member (setup form)
    window.editMember = (id) => {
        const member = allMembers.find(m => m._id === id);
        if (member) openModal(member);
    };

    // Search functionality
    searchInput.addEventListener('input', (e) => {
        const term = e.target.value.toLowerCase();
        const filtered = allMembers.filter(m => 
            m.name.toLowerCase().includes(term) || 
            m.trainer.toLowerCase().includes(term) ||
            m.plan.toLowerCase().includes(term)
        );
        renderMembers(filtered);
    });

    // Initial fetch
    fetchMembers();
});
