from flask import Flask, render_template, request, jsonify
from pymongo import MongoClient
from bson.objectid import ObjectId
from datetime import datetime
import os

app = Flask(__name__)

# MongoDB Configuration
# Replace with your Atlas URI if needed: "mongodb+srv://<username>:<password>@cluster0.exmple.mongodb.net/"
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
client = MongoClient(MONGO_URI)
db = client.gym_database
members_collection = db.members

@app.route('/')
def index():
    return render_template('index.html')

# API Routes

@app.route('/api/members', methods=['GET'])
def get_members():
    members = list(members_collection.find())
    for member in members:
        member['_id'] = str(member['_id'])
    return jsonify(members)

@app.route('/api/members', methods=['POST'])
def add_member():
    data = request.json
    new_member = {
        "name": data.get("name"),
        "age": int(data.get("age")),
        "plan": data.get("plan"),
        "trainer": data.get("trainer"),
        "joining_date": data.get("joining_date", datetime.now().strftime("%Y-%m-%d")),
        "created_at": datetime.now()
    }
    result = members_collection.insert_one(new_member)
    return jsonify({"message": "Member added successfully", "id": str(result.inserted_id)}), 201

@app.route('/api/members/<id>', methods=['PUT'])
def update_member(id):
    data = request.json
    update_data = {
        "name": data.get("name"),
        "age": int(data.get("age")),
        "plan": data.get("plan"),
        "trainer": data.get("trainer"),
        "joining_date": data.get("joining_date")
    }
    # Remove None values
    update_data = {k: v for k, v in update_data.items() if v is not None}
    
    result = members_collection.update_one({"_id": ObjectId(id)}, {"$set": update_data})
    if result.matched_count:
        return jsonify({"message": "Member updated successfully"})
    return jsonify({"error": "Member not found"}), 404

@app.route('/api/members/<id>', methods=['DELETE'])
def delete_member(id):
    result = members_collection.delete_one({"_id": ObjectId(id)})
    if result.deleted_count:
        return jsonify({"message": "Member deleted successfully"})
    return jsonify({"error": "Member not found"}), 404

if __name__ == '__main__':
    app.run(debug=True, port=5000)
