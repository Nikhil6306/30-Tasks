/* ─── STATE ──────────────────────────────────── */
let allProducts = [];
let deleteTarget = null;
let searchTimeout = null;

/* ─── INIT ───────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  setupNav();
  setupForm();
  setupSearch();
  loadDashboard();
});

/* ─── NAVIGATION ─────────────────────────────── */
function setupNav() {
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', e => {
      e.preventDefault();
      switchView(item.dataset.view);
    });
  });
}

function switchView(view) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.querySelector(`[data-view="${view}"]`).classList.add('active');

  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(`view-${view}`).classList.add('active');

  const titles = { dashboard: 'Dashboard', products: 'Products', add: 'Add Product' };
  document.getElementById('page-title').textContent = titles[view] || view;

  const searchWrap = document.getElementById('search-wrap');
  const catFilter  = document.getElementById('category-filter');
  if (view === 'products') {
    searchWrap.style.display = 'block';
    catFilter.style.display = 'block';
    loadProducts();
    loadCategories();
  } else {
    searchWrap.style.display = 'none';
    catFilter.style.display = 'none';
  }
  if (view === 'dashboard') loadDashboard();
}

/* ─── DASHBOARD ──────────────────────────────── */
async function loadDashboard() {
  try {
    const [stats, products] = await Promise.all([
      api('/api/stats'),
      api('/api/products?sort=created_at&order=desc')
    ]);

    animateNumber('stat-total', stats.total_products);
    animateNumber('stat-cats', stats.categories);
    animateNumber('stat-low', stats.low_stock);
    animateNumber('stat-out', stats.out_of_stock);
    document.getElementById('stat-value').textContent = formatPrice(stats.total_inventory_value);

    const container = document.getElementById('recent-products');
    const recent = products.slice(0, 5);
    if (recent.length === 0) {
      container.innerHTML = '<div style="color:var(--text-muted);font-size:13px;padding:12px 0">No products yet.</div>';
      return;
    }
    container.innerHTML = recent.map(p => `
      <div class="recent-item">
        <div class="recent-thumb">
          ${p.image_url ? `<img src="${escHtml(p.image_url)}" alt="" onerror="this.parentElement.textContent='◈'">` : '◈'}
        </div>
        <div class="recent-info">
          <div class="recent-name">${escHtml(p.name)}</div>
          <div class="recent-cat">${escHtml(p.category)}</div>
        </div>
        <div class="recent-price">${formatPrice(p.price)}</div>
      </div>
    `).join('');
  } catch (err) {
    showToast('Failed to load dashboard', 'error');
  }
}

function animateNumber(id, target) {
  const el = document.getElementById(id);
  let current = 0;
  const step = Math.ceil(target / 20);
  const interval = setInterval(() => {
    current = Math.min(current + step, target);
    el.textContent = current;
    if (current >= target) clearInterval(interval);
  }, 40);
}

/* ─── PRODUCTS LIST ──────────────────────────── */
async function loadProducts(search = '', category = 'All') {
  const tbody = document.getElementById('products-tbody');
  tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;padding:30px;color:var(--text-muted)">Loading…</td></tr>`;
  try {
    let url = `/api/products?search=${encodeURIComponent(search)}`;
    if (category && category !== 'All') url += `&category=${encodeURIComponent(category)}`;
    allProducts = await api(url);
    renderProductsTable(allProducts);
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;padding:30px;color:var(--accent-red)">Failed to load products</td></tr>`;
  }
}

function renderProductsTable(products) {
  const tbody   = document.getElementById('products-tbody');
  const empty   = document.getElementById('empty-state');
  const countEl = document.getElementById('products-count');

  countEl.textContent = `${products.length} product${products.length !== 1 ? 's' : ''}`;

  if (products.length === 0) {
    tbody.innerHTML = '';
    empty.style.display = 'flex';
    return;
  }
  empty.style.display = 'none';

  tbody.innerHTML = products.map(p => {
    const stockStatus = p.stock === 0 ? 'out-stock' : p.stock <= 5 ? 'low-stock' : 'in-stock';
    const stockLabel  = p.stock === 0 ? 'Out of Stock' : p.stock <= 5 ? 'Low Stock' : 'In Stock';
    const thumb = p.image_url
      ? `<div class="product-thumb"><img src="${escHtml(p.image_url)}" alt="" onerror="this.parentElement.textContent='◈'"></div>`
      : `<div class="product-thumb">◈</div>`;
    return `
      <tr>
        <td>
          <div class="product-cell">
            ${thumb}
            <div>
              <div class="product-name">${escHtml(p.name)}</div>
              ${p.description ? `<div class="product-desc">${escHtml(p.description)}</div>` : ''}
            </div>
          </div>
        </td>
        <td><span class="cat-tag">${escHtml(p.category)}</span></td>
        <td class="price-cell">${formatPrice(p.price)}</td>
        <td class="stock-cell">${p.stock}</td>
        <td><span class="status-badge ${stockStatus}">${stockLabel}</span></td>
        <td class="actions-cell">
          <button class="btn-edit" onclick="editProduct('${p._id}')">✎ Edit</button>
          <button class="btn-del" onclick="confirmDelete('${p._id}', '${escAttr(p.name)}')">✕ Delete</button>
        </td>
      </tr>
    `;
  }).join('');
}

/* ─── CATEGORIES ─────────────────────────────── */
async function loadCategories() {
  try {
    const cats = await api('/api/categories');
    const select = document.getElementById('category-filter');
    const existing = Array.from(select.options).map(o => o.value);
    cats.forEach(c => {
      if (!existing.includes(c)) {
        const opt = document.createElement('option');
        opt.value = c; opt.textContent = c;
        select.appendChild(opt);
      }
    });

    // datalist for form
    const dl = document.getElementById('cat-list');
    dl.innerHTML = cats.map(c => `<option value="${escAttr(c)}">`).join('');
  } catch {}
}

/* ─── SEARCH ─────────────────────────────────── */
function setupSearch() {
  document.getElementById('search-input').addEventListener('input', e => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      const cat = document.getElementById('category-filter').value;
      loadProducts(e.target.value, cat);
    }, 300);
  });

  document.getElementById('category-filter').addEventListener('change', e => {
    const search = document.getElementById('search-input').value;
    loadProducts(search, e.target.value);
  });
}

/* ─── FORM ───────────────────────────────────── */
function setupForm() {
  document.getElementById('product-form').addEventListener('submit', handleSubmit);

  document.getElementById('f-image').addEventListener('input', e => {
    const url = e.target.value.trim();
    const wrap = document.getElementById('image-preview-wrap');
    const img  = document.getElementById('image-preview');
    if (url) {
      wrap.style.display = 'block';
      img.src = url;
      img.onerror = () => { wrap.style.display = 'none'; };
    } else {
      wrap.style.display = 'none';
    }
  });
}

async function handleSubmit(e) {
  e.preventDefault();
  clearErrors();

  const name     = document.getElementById('f-name').value.trim();
  const price    = document.getElementById('f-price').value;
  const stock    = document.getElementById('f-stock').value;
  const category = document.getElementById('f-category').value.trim();
  const image_url = document.getElementById('f-image').value.trim();
  const description = document.getElementById('f-desc').value.trim();
  const editId   = document.getElementById('edit-id').value;

  let valid = true;
  if (!name) { showFieldErr('err-name', 'Product name is required'); setInputError('f-name'); valid = false; }
  if (!price || isNaN(price) || +price < 0) { showFieldErr('err-price', 'Enter a valid price'); setInputError('f-price'); valid = false; }
  if (stock === '' || isNaN(stock) || +stock < 0) { showFieldErr('err-stock', 'Enter a valid stock quantity'); setInputError('f-stock'); valid = false; }
  if (!category) { showFieldErr('err-cat', 'Category is required'); setInputError('f-category'); valid = false; }
  if (!valid) return;

  const payload = { name, price: +price, stock: +stock, category, image_url, description };
  const btn = document.getElementById('submit-btn');
  btn.disabled = true;
  btn.textContent = editId ? 'Saving…' : 'Adding…';

  try {
    if (editId) {
      await api(`/api/products/${editId}`, 'PUT', payload);
      showToast('Product updated successfully!', 'success');
      resetForm();
    } else {
      await api('/api/products', 'POST', payload);
      showToast('Product added successfully!', 'success');
      resetForm();
    }
    setTimeout(() => switchView('products'), 600);
  } catch (err) {
    showToast(err.message || 'Something went wrong', 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = editId ? '✓ Save Changes' : '⊕ Add Product';
  }
}

async function editProduct(id) {
  try {
    const p = await api(`/api/products/${id}`);
    switchView('add');
    document.getElementById('form-title').textContent = 'Edit Product';
    document.getElementById('form-subtitle').textContent = 'Update the product details below.';
    document.getElementById('page-title').textContent = 'Edit Product';
    document.getElementById('edit-id').value = p._id;
    document.getElementById('f-name').value = p.name;
    document.getElementById('f-price').value = p.price;
    document.getElementById('f-stock').value = p.stock;
    document.getElementById('f-category').value = p.category;
    document.getElementById('f-image').value = p.image_url || '';
    document.getElementById('f-desc').value = p.description || '';
    document.getElementById('submit-btn').textContent = '✓ Save Changes';
    document.getElementById('cancel-btn').style.display = 'inline-flex';

    if (p.image_url) {
      document.getElementById('image-preview-wrap').style.display = 'block';
      document.getElementById('image-preview').src = p.image_url;
    }
    loadCategories();
  } catch {
    showToast('Failed to load product', 'error');
  }
}

function cancelEdit() {
  resetForm();
  switchView('products');
}

function resetForm() {
  document.getElementById('product-form').reset();
  document.getElementById('edit-id').value = '';
  document.getElementById('form-title').textContent = 'Add New Product';
  document.getElementById('form-subtitle').textContent = 'Fill in the details below to add a product to your inventory.';
  document.getElementById('submit-btn').textContent = '⊕ Add Product';
  document.getElementById('cancel-btn').style.display = 'none';
  document.getElementById('image-preview-wrap').style.display = 'none';
  clearErrors();
}

/* ─── DELETE ─────────────────────────────────── */
function confirmDelete(id, name) {
  deleteTarget = id;
  document.getElementById('modal-body').textContent = `"${name}" will be permanently removed.`;
  document.getElementById('modal-overlay').style.display = 'flex';
  document.getElementById('modal-confirm').onclick = doDelete;
}

async function doDelete() {
  closeModal();
  try {
    await api(`/api/products/${deleteTarget}`, 'DELETE');
    showToast('Product deleted', 'success');
    loadProducts(
      document.getElementById('search-input').value,
      document.getElementById('category-filter').value
    );
    loadCategories();
  } catch {
    showToast('Failed to delete product', 'error');
  }
  deleteTarget = null;
}

function closeModal() {
  document.getElementById('modal-overlay').style.display = 'none';
}

document.getElementById('modal-overlay').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeModal();
});

/* ─── API HELPER ─────────────────────────────── */
async function api(url, method = 'GET', body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
  };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

/* ─── HELPERS ────────────────────────────────── */
function formatPrice(price) {
  return '₹' + Number(price).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function escAttr(str) {
  return String(str).replace(/'/g,'&#39;').replace(/"/g,'&quot;');
}

function showToast(msg, type = 'info') {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.className = `toast ${type} show`;
  setTimeout(() => { toast.className = 'toast'; }, 3000);
}

function showFieldErr(id, msg) {
  document.getElementById(id).textContent = msg;
}

function setInputError(id) {
  document.getElementById(id).classList.add('error');
  document.getElementById(id).addEventListener('input', () => {
    document.getElementById(id).classList.remove('error');
  }, { once: true });
}

function clearErrors() {
  ['err-name','err-price','err-stock','err-cat'].forEach(id => {
    document.getElementById(id).textContent = '';
  });
  ['f-name','f-price','f-stock','f-category'].forEach(id => {
    document.getElementById(id).classList.remove('error');
  });
}
