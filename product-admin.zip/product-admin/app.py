from flask import Flask, request, jsonify, render_template
from pymongo import MongoClient
from bson import ObjectId
from bson.errors import InvalidId
import datetime
import os

app = Flask(__name__)

# MongoDB Connection
MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/")
client = MongoClient(MONGO_URI)
db = client["ecommerce_admin"]
products_collection = db["products"]

# Helper: convert ObjectId to string
def serialize_product(product):
    product["_id"] = str(product["_id"])
    return product

# ─────────────────────────────────────────────
#  ROUTES
# ─────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


# ── READ ALL (with optional search/filter) ───
@app.route("/api/products", methods=["GET"])
def get_products():
    query = {}
    search = request.args.get("search", "").strip()
    category = request.args.get("category", "").strip()
    sort_by = request.args.get("sort", "created_at")
    order = request.args.get("order", "desc")

    if search:
        query["$or"] = [
            {"name": {"$regex": search, "$options": "i"}},
            {"category": {"$regex": search, "$options": "i"}},
        ]
    if category and category != "All":
        query["category"] = category

    sort_dir = -1 if order == "desc" else 1
    products = list(products_collection.find(query).sort(sort_by, sort_dir))
    return jsonify([serialize_product(p) for p in products])


# ── READ ONE ──────────────────────────────────
@app.route("/api/products/<product_id>", methods=["GET"])
def get_product(product_id):
    try:
        product = products_collection.find_one({"_id": ObjectId(product_id)})
        if not product:
            return jsonify({"error": "Product not found"}), 404
        return jsonify(serialize_product(product))
    except InvalidId:
        return jsonify({"error": "Invalid product ID"}), 400


# ── CREATE ────────────────────────────────────
@app.route("/api/products", methods=["POST"])
def create_product():
    data = request.get_json()
    errors = validate_product(data)
    if errors:
        return jsonify({"error": errors}), 400

    product = {
        "name": data["name"].strip(),
        "price": float(data["price"]),
        "category": data["category"].strip(),
        "stock": int(data["stock"]),
        "image_url": data.get("image_url", "").strip(),
        "description": data.get("description", "").strip(),
        "created_at": datetime.datetime.utcnow(),
        "updated_at": datetime.datetime.utcnow(),
    }
    result = products_collection.insert_one(product)
    product["_id"] = str(result.inserted_id)
    return jsonify(product), 201


# ── UPDATE ────────────────────────────────────
@app.route("/api/products/<product_id>", methods=["PUT"])
def update_product(product_id):
    try:
        data = request.get_json()
        errors = validate_product(data)
        if errors:
            return jsonify({"error": errors}), 400

        update_data = {
            "name": data["name"].strip(),
            "price": float(data["price"]),
            "category": data["category"].strip(),
            "stock": int(data["stock"]),
            "image_url": data.get("image_url", "").strip(),
            "description": data.get("description", "").strip(),
            "updated_at": datetime.datetime.utcnow(),
        }
        result = products_collection.update_one(
            {"_id": ObjectId(product_id)}, {"$set": update_data}
        )
        if result.matched_count == 0:
            return jsonify({"error": "Product not found"}), 404

        updated = products_collection.find_one({"_id": ObjectId(product_id)})
        return jsonify(serialize_product(updated))
    except InvalidId:
        return jsonify({"error": "Invalid product ID"}), 400


# ── DELETE ────────────────────────────────────
@app.route("/api/products/<product_id>", methods=["DELETE"])
def delete_product(product_id):
    try:
        result = products_collection.delete_one({"_id": ObjectId(product_id)})
        if result.deleted_count == 0:
            return jsonify({"error": "Product not found"}), 404
        return jsonify({"message": "Product deleted successfully"})
    except InvalidId:
        return jsonify({"error": "Invalid product ID"}), 400


# ── STATS ─────────────────────────────────────
@app.route("/api/stats", methods=["GET"])
def get_stats():
    total_products = products_collection.count_documents({})
    low_stock = products_collection.count_documents({"stock": {"$lte": 5}})
    out_of_stock = products_collection.count_documents({"stock": 0})

    pipeline = [{"$group": {"_id": "$category", "count": {"$sum": 1}}}]
    categories = list(products_collection.aggregate(pipeline))

    total_value_pipeline = [
        {"$group": {"_id": None, "total": {"$sum": {"$multiply": ["$price", "$stock"]}}}}
    ]
    value_result = list(products_collection.aggregate(total_value_pipeline))
    total_value = value_result[0]["total"] if value_result else 0

    return jsonify({
        "total_products": total_products,
        "low_stock": low_stock,
        "out_of_stock": out_of_stock,
        "categories": len(categories),
        "total_inventory_value": round(total_value, 2),
    })


# ── CATEGORIES ────────────────────────────────
@app.route("/api/categories", methods=["GET"])
def get_categories():
    categories = products_collection.distinct("category")
    return jsonify(sorted(categories))


# ── VALIDATION ────────────────────────────────
def validate_product(data):
    if not data:
        return "No data provided"
    if not data.get("name", "").strip():
        return "Product name is required"
    if data.get("price") is None:
        return "Price is required"
    try:
        price = float(data["price"])
        if price < 0:
            return "Price must be non-negative"
    except (ValueError, TypeError):
        return "Price must be a valid number"
    if data.get("stock") is None:
        return "Stock quantity is required"
    try:
        stock = int(data["stock"])
        if stock < 0:
            return "Stock must be non-negative"
    except (ValueError, TypeError):
        return "Stock must be a valid integer"
    if not data.get("category", "").strip():
        return "Category is required"
    return None


if __name__ == "__main__":
    app.run(debug=True, port=5000)
