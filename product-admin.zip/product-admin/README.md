# PRODEX — E-Commerce Product Admin Panel

A full-stack admin panel for managing e-commerce products with complete CRUD operations.

## Tech Stack
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Backend**: Python Flask
- **Database**: MongoDB

## Project Structure
```
prodex/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── css/
    │   └── style.css
    └── js/
        └── app.js
```

## Setup & Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Start MongoDB
```bash
# Using mongod directly
mongod --dbpath /data/db

# Or with Docker
docker run -d -p 27017:27017 mongo:latest
```

### 3. Run the Flask server
```bash
python app.py
```

### 4. Open browser
Visit: http://localhost:5000
